용량 제한으로 인해 소스코드만 올립니다.
https://github.com/MinDarin/rtsp_streaming_app_public에서 상세히 확인하실 수 있습니다.