package house.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBManager {
	private static final String URL = "jdbc:mysql://127.0.0.1:3306/ssafyweb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String ID = "root";
	private static final String PASSWORD = "twinsangel1996^^";

	static { // 최초 로드되는 순간만 생성
		try {
			Class.forName(DRIVER);

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnect() throws SQLException {
		return DriverManager.getConnection(URL, ID, PASSWORD);
	}

	public static void close(AutoCloseable... closeables) { //같은 데이터 타입만 가능
		try {
			for (AutoCloseable autoCloseable : closeables) {
				if (autoCloseable != null)
					autoCloseable.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
