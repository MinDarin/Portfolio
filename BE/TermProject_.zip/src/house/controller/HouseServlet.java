package house.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import house.dto.FavoriteDto;
import house.dto.HouseDto;
import house.dto.PollutionDto;
import house.dto.RestaurantDto;
import house.dto.SelectDto;
import house.dto.UserDto;
import house.service.FavorateServiceImpl;
import house.service.HouseServiceImpl;

@WebServlet("/house/*")
public class HouseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request,response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) {
		response.setContentType("text/html; charset=utf-8");
		String contextPath = request.getContextPath();
		String path = request.getRequestURI().substring(contextPath.length());
		switch(path) {
			case "/house/info" : houseInfo(request, response); break; //거래가 정보
			case "/house/TotalCnt" : houseTotalCnt(request, response); break; //거래가 정보
			case "/house/favorite": hosueFavoriate(request, response); break; //관심지역오염도 등
			case "/house/mvfavorite": hosueMvFavoriate(request, response); break; //관심지역오염도 등
			case "/house/si_gu_dong": houseGetSiGuDong(request,response); break;
			case "/house/addFavoirteRegion": houseAddFavoirteRegion(request,response); break;
			case "/house/getFavoirteRegion": houseGetFavoirteRegion(request,response); break;
			case "/house/removeFavoirteRegion": houseRemoveFavoirteRegion(request,response); break;
			case "/house/setfavorite" : houseMvSetFavoirteRegion(request,response); break;
			default : notValidUrl(request,response);
		}		
	}
	private void houseMvSetFavoirteRegion(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			response.sendRedirect(request.getContextPath()+"/jsp/add_favorite_region.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void houseRemoveFavoirteRegion(HttpServletRequest request, HttpServletResponse response) {
		System.out.println(request.getParameter("code"));
		HouseServiceImpl.getInstance().deleteRegion(request.getParameter("code"));
		RequestDispatcher disp = request.getRequestDispatcher("/jsp/add_favorite_region.jsp");
		try {
			disp.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void houseGetFavoirteRegion(HttpServletRequest request, HttpServletResponse response) {
		UserDto session = (UserDto)request.getSession().getAttribute("userinfo");
		//도중에 세션이 풀릴 수 도 있으니
		if(session == null) {
			try {
				response.getWriter().append("logout");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		else {
		//		System.out.println(request.getParameter("code")+"동 코드임");
		List<FavoriteDto> ret = HouseServiceImpl.getInstance().getRegion(session.getSeq());
		String strjson = new Gson().toJson(ret);
		System.out.println(strjson);
		try {
			response.getWriter().append(strjson);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}		
	}

	private void houseAddFavoirteRegion(HttpServletRequest request, HttpServletResponse response) {
		UserDto session = (UserDto)request.getSession().getAttribute("userinfo");
		//도중에 세션이 풀릴 수 도 있으니
		if(session == null) {
			try {
				response.getWriter().append("logout");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		else {
		HouseServiceImpl.getInstance().addRegion(session.getSeq(),request.getParameter("si"),request.getParameter("gun"),request.getParameter("dong"));
		}
	}

	private void houseGetSiGuDong(HttpServletRequest request, HttpServletResponse response) {
		String key = request.getParameter("key");
		String code = request.getParameter("code");
		System.out.println("select : "+key+"/"+code);
		System.out.println(key);
		List<SelectDto> list = HouseServiceImpl.getInstance().getSelect(key, code);
		String jsonstr = new Gson().toJson(list);
		System.out.println(jsonstr);
		try {
			response.getWriter().append(jsonstr);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void houseTotalCnt(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String key = request.getParameter("key");
		String word = request.getParameter("word");
		System.out.println("key"+"word");
		int last = HouseServiceImpl.getInstance().getTotal(key, word);
		System.out.println("total"+last);
		try {
			response.getWriter().append(""+last);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void notValidUrl(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			response.sendRedirect(request.getContextPath()+"/jsp/error/error404.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void hosueMvFavoriate(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			response.sendRedirect(request.getContextPath()+"/jsp/favorite_region.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}


	private void  hosueFavoriate(HttpServletRequest request, HttpServletResponse response) {
		String key = request.getParameter("key");
		String word = request.getParameter("word");
		System.out.println("key and word : "+key+" and "+word);
		HttpSession session = request.getSession();
		if(key.equals("pol")) {
			List<PollutionDto> polList = null;
			try {
				polList = FavorateServiceImpl.getInstance().getPollution(key,word);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			session.setAttribute("polList",polList);
			try {
				response.sendRedirect(request.getContextPath()+"/house/mvfavorite");
//				RequestDispatcher dispatcher = request.getRequestDispatcher(request.getContextPath()+"/house/mvfavorite");
//				dispatcher.forward(request, response);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(key.equals("res")){
			System.out.println("hit res servlet!");

			List<RestaurantDto> resList = null;
			try {
				resList = FavorateServiceImpl.getInstance().getRestaurant(key,word);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			session.setAttribute("resList",resList);			
			try {
				response.sendRedirect(request.getContextPath()+"/house/mvfavorite");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			notValidUrl(request,response);
		}
	}

	private void houseInfo(HttpServletRequest request, HttpServletResponse response){
		String async = request.getHeader("async");
		System.out.println(async);
		if("false".equals(async) || async == null) {
			RequestDispatcher disp = request.getRequestDispatcher("/jsp/result.jsp");
			try {
				disp.forward(request, response);
			} catch (ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
		String word = request.getParameter("word");
		String key = request.getParameter("key");
		String strLimit = request.getParameter("limit");
		String strOffset = request.getParameter("offset");
		System.out.println("inServlet "+word+"/"+key+"/"+strOffset+"/"+strLimit);

		int limit = Integer.parseInt(strLimit);
		int offset = Integer.parseInt(strOffset);

			List<HouseDto> houseDto = HouseServiceImpl.getInstance().getInfo(key, word,limit,offset);
			String jsonStr = new Gson().toJson(houseDto);
			System.out.println(jsonStr.length());
			try {
				response.getWriter().append(jsonStr);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}	
}
