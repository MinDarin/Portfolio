package house.controller;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import house.dto.UserDto;

// no exclude
@WebFilter("/*")
public class LoginFilter implements Filter{

	@Override
	public void destroy() {}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest httpServletRequest = (HttpServletRequest) req;
		HttpServletResponse httpServletResponse = (HttpServletResponse) res;
		
		String contextPath = httpServletRequest.getContextPath();
		String path = httpServletRequest.getRequestURI();
		
		HttpSession session = httpServletRequest.getSession();
		
		//해당 jsp들은 서버로부터 데이터를 받아 출력하는 초기 동작이 있기에 jsp를 통한 직접적인 접근은 불가능 하도록 해야합니다.	
//		String nextPath = "";
//		if(path.contains("notice.jsp")) {
//			System.out.println("jsp로 바로 이동할 순 없습니다.");
//			nextPath = "/notice/list";			
//			httpServletRequest.getRequestDispatcher(nextPath).forward(httpServletRequest, httpServletResponse);
//		}
//		else if(path.contains("result.jsp")) {
//			System.out.println("jsp로 바로 이동할 순 없습니다.");
//			nextPath = "/house/info";				
//			httpServletRequest.getRequestDispatcher(nextPath).forward(httpServletRequest, httpServletResponse);
//		}
//		else if(path.contains("favorite_region.jsp")) {
//			System.out.println("jsp로 바로 이동할 순 없습니다.");
//			nextPath = "/house/mvfavorite";				
//			httpServletRequest.getRequestDispatcher(nextPath).forward(httpServletRequest, httpServletResponse);
//		}
//		else if(!path.contains("login.jsp")) {
//			if(path.contains(".jsp")) {
//				nextPath = "/";				
//				httpServletRequest.getRequestDispatcher(nextPath).forward(httpServletRequest, httpServletResponse);				
//			}
//		}
//		
		if( path.contains("/notice/delete") || path.contains("/notice/write") || path.contains("/notice/mvmodify") || path.contains("/house/mvfavorite") ) 
		{

			UserDto userDto = (UserDto) session.getAttribute("userinfo");
			if(userDto == null) {				
				if("true".equals(httpServletRequest.getHeader("async"))) {
					Gson gson = new Gson();

					JsonObject jsonObject = new JsonObject();
					jsonObject.addProperty("result", "login");
					
					String jsonStr = gson.toJson(jsonObject);
					httpServletResponse.getWriter().write(jsonStr);
				}else {
					httpServletResponse.sendRedirect(contextPath + "/");
				}
				return;
			}
		}

		chain.doFilter(req, res);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
