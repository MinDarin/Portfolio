package house.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import house.dto.NoticeDto;
import house.dto.UserDto;
import house.service.NoticeServiceImpl;

@WebServlet("/notice/*")

@MultipartConfig(fileSizeThreshold = 1024 * 1024, maxFileSize = 1024 * 1024 * 5, maxRequestSize = 1024 * 1024 * 5 * 5)

public class NoticeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String uploadPath;

	@Override
	public void init() {
		uploadPath = "C:" + File.separator + "Users" + File.separator + "memen" + File.separator +"eclipse_workspace_SSAFY"+ File.separator+ "BackEnd"+ File.separator+"TermProject5" + File.separator+"TermProject5_2조_서울_13반_김민석_최윤아"+File.separator + "WebContent";
		System.out.println(uploadPath);
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");

		String contextPath = request.getContextPath();
		String path = request.getRequestURI().substring(contextPath.length());
		System.out.println(path);

		switch (path) {
		case "/notice/list":
			list(request, response);
			break; // 글 목록
		case "/notice/mvwrite":
			mvwrite(request, response);
			break; // 글쓰기 화면으로 이동
		case "/notice/write":
			write(request, response);
			break; // 글쓰기
		case "/notice/mvmodify":
			mvmodify(request, response);
			break; // 수정페이지로 이동
		case "/notice/delete":
			delete(request, response);
			break; // 삭제 이동
		case "/notice/modify":
			modify(request, response);
			break; // 수정페이지로 이동
		}

	}

	private void modify(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String path = "/index.jsp";
		
		try {
			
			NoticeDto noticeDto = new NoticeDto();
			noticeDto.setArticleNo(Integer.parseInt(request.getParameter("articleno")));
			noticeDto.setContent(request.getParameter("content"));
			
			System.out.println(request.getParameter("file"));
			NoticeServiceImpl.getNoticeService().modifyArticle(noticeDto);
			noticeDto = NoticeServiceImpl.getNoticeService().boardUpdate(noticeDto, request.getParts(), uploadPath);
					
			System.out.println(noticeDto);
			
			request.setAttribute("article", noticeDto);
			path = "/notice/list";
			System.out.println("수정완료");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글 수정 중 문제가 발생했습니다.");
			path = "/jsp/error/error500.jsp";

		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		int articleno = Integer.parseInt(request.getParameter("articleno"));
		System.out.println(articleno);
		try {
			System.out.println("articleno " + articleno);
			NoticeServiceImpl.getNoticeService().deleteArticle(articleno, uploadPath);
			request.getRequestDispatcher("/notice/list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글삭제 처리 중 문제가 발생했습니다.");
			path = "/jsp/error/error500.jsp";
			request.getRequestDispatcher(path).forward(request, response);
		}
	}

	private void mvmodify(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "/index.jsp";
		HttpSession session = request.getSession();
		UserDto userDto = (UserDto) session.getAttribute("userinfo");
		int articleno = Integer.parseInt(request.getParameter("articleno"));
		boolean flag = Boolean.parseBoolean(request.getParameter("flag"));
		try {
			
			if (flag) {				
				NoticeDto noticeDto = NoticeServiceImpl.getNoticeService().getArticle(articleno);
				request.setAttribute("article", noticeDto);
				path = "/jsp/modify.jsp";
			} else {
				NoticeDto noticeDto = NoticeServiceImpl.getNoticeService().getArticle(articleno);
				request.setAttribute("article", noticeDto);
				path = "/jsp/mvmodify.jsp";
			}

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글 수정 처리 중 문제가 발생했습니다.");
			path = "/jsp/error/error500.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void write(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		HttpSession session = request.getSession();
		UserDto userDto = (UserDto) session.getAttribute("userinfo");
		if (userDto != null) {
			System.out.println(request.getParameter("file"));
			NoticeDto noticeDto = new NoticeDto();
			noticeDto.setUserId(userDto.getUserId());
			noticeDto.setSubject(request.getParameter("subject"));
			noticeDto.setContent(request.getParameter("content"));

			try {
				int boardId = NoticeServiceImpl.getNoticeService().boardInsert(noticeDto, request.getParts(),
						uploadPath);
				// 글작성 성공
				System.out.println("글작성 성공");
				path = "/notice/list";
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "글작성 중 문제가 발생하였습니다. 입니다.");
				path = "/jsp/error/error500.jsp";
			}

		} else {
			request.setAttribute("msg", "로그인 후 사용 가능한 서비스 입니다.");
			path = "/jsp/error/error500.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);

	}

	private void mvwrite(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String root = request.getContextPath();
		response.sendRedirect(root + "/jsp/write.jsp");
	}

	private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String key = request.getParameter("key");
		String word = request.getParameter("word");
		try {
			List<NoticeDto> list = NoticeServiceImpl.getNoticeService().listArticle(key, word);
			if ("true".equals(request.getHeader("async"))) {
				String jsonStr = new Gson().toJson(list);
				response.getWriter().append(jsonStr);
				System.out.println("Deleted");
			} else {
				request.setAttribute("articles", list);
				path = "/jsp/notice.jsp";
				request.getRequestDispatcher(path).forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "공지 목록을 얻어오는 중 문제가 발생했습니다.");
			path = "/jsp/error/error500.jsp";
			request.getRequestDispatcher(path).forward(request, response);
		}
	}

}
