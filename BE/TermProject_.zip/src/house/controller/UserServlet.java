package house.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import house.dto.UserDto;
import house.service.UserServiceImpl;

@WebServlet("/user/*")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");

		String contextPath = request.getContextPath();
		String path = request.getRequestURI().substring(contextPath.length());

		System.out.println(path);
		switch (path) {
		case "/user/info":
			userInfo(request, response);
			break; // 회원정보
		case "/user/register":
			userRegister(request, response);
			break; // 회원 가입
		case "/user/login":
			userLogin(request, response);
			break; // 로그인
		case "/user/logout":
			userLogout(request, response);
			break; // 로그아웃
		case "/user/infomodify":
			userInfoModify(request, response);
			break; // 회원정보수정
		case "/user/infodelete":
			userInfoDelete(request, response);
			break; // 회원정보삭제
		// default : notValidUrl();

		}
	}

	private void userInfoDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/jsp/index.jsp";
		
		String userid = request.getParameter("id");
		
		try {
			UserServiceImpl.getUserService().deleteMember(userid);
			System.out.println("회원 삭제 성공");
			path = "/user/logout";

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글삭제 처리 중 문제가 발생했습니다.");
			path = "/jsp/error/error500.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void userInfoModify(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path = "/user/index.jsp";

		String userId = request.getParameter("id");
		String userName = request.getParameter("name");
		String userPwd = request.getParameter("pwd");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		
		UserDto userDto = new UserDto();
		userDto.setUserId(userId);
		userDto.setUserName(userName);
		userDto.setUserPwd(userPwd);
		userDto.setAddress(address);
		userDto.setEmail(email);
		userDto.setPhone(phone);
		
		try {
			UserServiceImpl.getUserService().modifyMember(userDto);
			System.out.println("수정 성공");
			path = "/user/info";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글 수정 중 문제가 발생했습니다.");
			path = "/jsp/error/error500.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void userLogout(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String root = request.getContextPath();
		HttpSession session = request.getSession();
		session.invalidate();
		response.sendRedirect(root + "/jsp/index.jsp");
	}

	private void userLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String userId = request.getParameter("userid"); // 데이터 받아오기
		String userPwd = request.getParameter("userpwd");

		UserDto userDto = UserServiceImpl.getUserService().login(userId, userPwd);

		String path = "/jsp/index.jsp";
		if (userDto != null) {// 성공 -> 응답페이지로 보내버린다 -> jsp
			// session 설정
			System.out.println("로그인 성공");
			HttpSession session = request.getSession();
			session.setAttribute("userinfo", userDto); 

		} else { // 로그인 실패
			request.setAttribute("msg", "가입하지 않은 아이디거나 잘못된 비밀번호입니다");
			path = "/jsp/error/error500.jsp";
		}
		RequestDispatcher disp = request.getRequestDispatcher(path);
		disp.forward(request, response);
	}


	private void userRegister(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";

		String userId = request.getParameter("id");
		String userName = request.getParameter("name");
		String userPwd = request.getParameter("pwd");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
	
		UserDto userDto = new UserDto();
		userDto.setUserId(userId);
		userDto.setUserName(userName);
		userDto.setUserPwd(userPwd);
		userDto.setAddress(address);
		userDto.setEmail(email);
		userDto.setPhone(phone);
		
		try {
			UserServiceImpl.getUserService().registerMember(userDto);
			//회원등록 성공
			System.out.println("회원 가입 성공");
			path = "/jsp/index.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "회원가입 중 문제가 발생하였습니다.");
			path = "/jsp/error/error500.jsp";	
		}
		request.getRequestDispatcher(path).forward(request, response);	
	}

	private void userInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/jsp/index.jsp";
		String userid = request.getParameter("id");
		
		try {
			UserDto userDto = UserServiceImpl.getUserService().getMember(userid);
			request.setAttribute("userinfo", userDto);
			path = "/jsp/userinfo.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글 수정 처리 중 문제가 발생했습니다.");
			path = "/jsp/error/error500.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

}
