package house.dao;

import java.util.List;

import house.dto.FavoriteDto;
import house.dto.HouseDto;
import house.dto.SelectDto;

public interface HouseDao {
	public List<HouseDto> getInfo(String key, String word, int limit, int offset);
	public List<SelectDto> getSelect(String key, String code);
	public List<FavoriteDto> getRegion(int seq);
}
