package house.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import house.common.DBManager;
import house.dto.FavoriteDto;
import house.dto.HouseDto;
import house.dto.SelectDto;

public class HouseDaoImpl implements HouseDao {

	private static HouseDaoImpl instance;
	private HouseDaoImpl() {}
	public static HouseDaoImpl getInstance() {
		if(instance == null) {
			instance = new HouseDaoImpl();
		}
		return instance;
	}
	public List<SelectDto> getSelect(String key, String code){
		System.out.println("DAO select"+key+"/"+code);
		ArrayList<SelectDto> result = new ArrayList();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
		conn = DBManager.getConnect();	
		StringBuilder sql = new StringBuilder("");

			if("sido".equals(key)) {
				sql.append("select name, code from sido_code");
				pstmt = conn.prepareStatement(sql.toString());
			}
			else if("gugun".equals(key)) {
				sql.append("select name, code from gugun_code where sido_code = ? ");			
				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setString(1, code);
			}
			else if("dong".equals(key)) {
				sql.append("select name, code from dong_code where gugun_code = ? ");
				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setString(1, code);				
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				SelectDto temp = new SelectDto();
				temp.setName(rs.getString("name"));
				temp.setCode(rs.getString("code"));
				result.add(temp);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			DBManager.close(rs, pstmt, conn);
		}

		return result;
	}
	public List<HouseDto> getInfo(String key, String word, int limit, int offset) {
		//db작업 필요
		ArrayList<HouseDto> resultList = new ArrayList<HouseDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
		conn = DBManager.getConnect();	
		StringBuilder sql = new StringBuilder("Select DISTINCT * from housedeal, houseinfo, gugun_code  where housedeal.AptName = houseinfo.AptName and housedeal.dong = houseinfo.dong \n");
		if(!word.isEmpty()) {

			if(key.equals("dong"))
				sql.append(" and housedeal.dong like ? \n");
			else
				sql.append(" and housedeal.AptName like ? \n");

			sql.append(" and houseinfo.code = gugun_code.code");
			sql.append(" LIMIT ? OFFSET ? ");
			pstmt = conn.prepareStatement(sql.toString());			
			pstmt.setString(1, "%"+word+"%");
			pstmt.setInt(2,limit);
			pstmt.setInt(3,offset);

		}			
		else {
			sql.append(" and houseinfo.code = gugun_code.code");
			sql.append(" LIMIT ? OFFSET ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1,limit);
			pstmt.setInt(2,offset);
		}
			rs = pstmt.executeQuery();
			System.out.println("inDao "+key+"/"+word);
			while(rs.next()) {
			HouseDto house = new HouseDto();
			house.setAptName(rs.getString("AptName"));
			house.setArea(rs.getString("area"));
			house.setBuildYear(rs.getString("buildYear"));
			house.setCode(rs.getString("code"));
			house.setDealAmount(rs.getString("dealAmount"));
			house.setDealDay(rs.getString("dealDay"));
			house.setDealMonth(rs.getString("dealMonth"));
			house.setDealYear(rs.getString("dealYear"));
			house.setDong(rs.getString("dong"));
			house.setFloor(rs.getString("floor"));
			house.setJibun(rs.getString("jibun"));
			house.setType(rs.getString("type"));
			house.setLat(rs.getString("lat"));
			house.setLng(rs.getString("lng"));
			house.setNo(rs.getInt("no"));
			house.setGugun(rs.getString("name"));
			resultList.add(house);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			DBManager.close(rs, pstmt, conn);
		}
		return resultList;

	} 
	public List<FavoriteDto> getRegion(int seq) {
		ArrayList<FavoriteDto> list = new ArrayList();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
		conn = DBManager.getConnect();	
		StringBuilder sql = new StringBuilder("Select sido_code.name as sido, gugun_code.name as gugun, dong_code.name as dong , dong_code.code as code from \r\n" + 
				"favoriteregion join sido_code\r\n" + 
				"on favoriteregion.sido = sido_code.code\r\n" + 
				"join gugun_code\r\n" + 
				"on favoriteregion.gugun = gugun_code.code\r\n" + 
				"join dong_code\r\n" + 
				"on favoriteregion.favoritePlace = dong_code.code\r\n" + 
				"where user_seq = ?;");
		pstmt = conn.prepareStatement(sql.toString());
		pstmt.setInt(1,seq);
		rs = pstmt.executeQuery();
			while(rs.next()) {
				FavoriteDto f = new FavoriteDto();
				f.setDong(rs.getString("dong"));
				f.setGun(rs.getString("gugun"));
				f.setSi(rs.getString("sido"));
				f.setDong_code(rs.getString("code"));
				list.add(f);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			DBManager.close(rs, pstmt, conn);
		}
		return list;
	}

	
	public void addRegion(int seq, String si, String gu, String dong) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		System.out.println(seq+"/"+si+"/"+gu+"/"+dong);
		try {
		conn = DBManager.getConnect();	
		StringBuilder sql = new StringBuilder("Insert into favoriteregion(user_seq,sido,gugun,favoritePlace) values (?,?,?,?) ");
		pstmt = conn.prepareStatement(sql.toString());
		pstmt.setInt(1, seq);
		pstmt.setString(2, si);
		pstmt.setString(3, gu);
		pstmt.setString(4, dong);
		pstmt.executeUpdate();		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			DBManager.close(rs, pstmt, conn);
		}
	}
	

	public void deleteRegion(String code){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
		conn = DBManager.getConnect();	
		StringBuilder sql = new StringBuilder("delete from favoriteregion where favoritePlace = ? ");
		pstmt = conn.prepareStatement(sql.toString());
		pstmt.setString(1, code);
		pstmt.executeUpdate();		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			DBManager.close(rs, pstmt, conn);
		}
	}

	public int getTotal(String key, String word) {
		//db작업 필요
		int ret = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		System.out.println("in total dao"+key+"/"+word);
		try {
		conn = DBManager.getConnect();	
		StringBuilder sql = new StringBuilder("Select count(*) from housedeal\n");
		if(!word.isEmpty()) {

			if(key.equals("dong"))
				sql.append(" where housedeal.dong like ? \n");
			else
				sql.append(" where housedeal.AptName like ? \n");
			pstmt = conn.prepareStatement(sql.toString());			
			pstmt.setString(1, "%"+word+"%");
		}			
		else {
			pstmt = conn.prepareStatement(sql.toString());
		}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ret = rs.getInt(1);
			}
			System.out.println("after total sql : "+ret);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			DBManager.close(rs, pstmt, conn);
		}
		return ret;

	} 

}
