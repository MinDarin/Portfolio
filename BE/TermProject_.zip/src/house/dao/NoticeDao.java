package house.dao;

import java.util.List;

import house.dto.NoticeFileDto;
import house.dto.NoticeDto;

public interface NoticeDao {
//	글작성
	int registerArticle(NoticeDto noticeDto) throws Exception;

//	글목록
	List<NoticeDto> listArticle(String key, String word) throws Exception;

//	글수정을 위한 글얻기
	NoticeDto getArticle(int articleNo) throws Exception;

//	글수정
	void modifyArticle(NoticeDto noticeDto) throws Exception;

//	글삭제
	void deleteArticle(int articleNo) throws Exception;

	int boardFileInsert(NoticeFileDto boardFileDto);

	List<NoticeFileDto> NoticeDetailFileList(int articleNo);

	List<String> NoticeFileUrlDeleteList(int articleNo);

	int NoticeFileDelete(int articleNo);

	void boardUpdate(NoticeDto noticeDto);

}
