package house.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import house.common.DBManager;
import house.dto.NoticeFileDto;
import house.dto.NoticeDto;

public class NoticeDaoImpl implements NoticeDao {

	// 싱글톤 패턴
	private static NoticeDao noticeDao;

	private NoticeDaoImpl() {
	}

	public static NoticeDao getNoticeDao() {
		if (noticeDao == null) {
			noticeDao = new NoticeDaoImpl();
		}
		return noticeDao;
	}

	@Override
	public List<NoticeDto> listArticle(String key, String word) throws Exception {
		List<NoticeDto> list = new ArrayList<NoticeDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBManager.getConnect();
			StringBuilder sql = new StringBuilder();
			sql.append("select articleno, user_id, subject, content, USER_REGISTER_DATE\n");
			sql.append("from notice \n");
			if (!word.isEmpty()) {
				if ("subject".equals(key)) { // 검색어가 있으면
					sql.append("where subject like ? \n");
				} else {
					sql.append("where " + key + " = ? \n");
				}
			}
			sql.append("order by articleno desc \n");
			pstmt = conn.prepareStatement(sql.toString());
			if (!word.isEmpty()) {
				if ("subject".equals(key))
					pstmt.setString(1, "%" + word + "%");
				else
					pstmt.setString(1, word);
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				NoticeDto noticeDto = new NoticeDto();
				noticeDto.setArticleNo(rs.getInt("articleno"));
				noticeDto.setUserId(rs.getString("user_id"));
				noticeDto.setSubject(rs.getString("subject"));
				noticeDto.setContent(rs.getString("content"));
				noticeDto.setRegtime(rs.getString("USER_REGISTER_DATE"));

				list.add(noticeDto);
			}
		} finally {
			DBManager.close(conn, pstmt, rs);
		}

		return list;
	}

	@Override
	public int registerArticle(NoticeDto noticeDto) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;

		int ret = -1;
		int cnt = 0;
		try {
			conn = DBManager.getConnect();
			StringBuilder insertMember = new StringBuilder();

			insertMember.append("insert into notice (USER_ID, SUBJECT, CONTENT, USER_REGISTER_DATE) \n");
			insertMember.append("values (?, ?, ?, now())");
			pstmt = conn.prepareStatement(insertMember.toString() , Statement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, noticeDto.getUserId());
			pstmt.setString(2, noticeDto.getSubject());
			pstmt.setString(3, noticeDto.getContent());

			cnt = pstmt.executeUpdate();
			if (cnt > 0) {
				ResultSet tableKeys = pstmt.getGeneratedKeys();

				if (tableKeys.next()) {
					ret = tableKeys.getInt(1);
				}
			}
		} finally {
			DBManager.close(pstmt, conn);
		}

		return ret;
	}

	@Override
	public NoticeDto getArticle(int articleNo) throws Exception {
		NoticeDto noticeDto = null;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBManager.getConnect();
			StringBuilder sql = new StringBuilder();
			sql.append("select articleno, USER_ID, SUBJECT, CONTENT, USER_REGISTER_DATE \n");
			sql.append("from notice \n");
			sql.append("where articleno = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, articleNo);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				noticeDto = new NoticeDto();
				noticeDto.setArticleNo(rs.getInt("articleno"));
				noticeDto.setUserId(rs.getString("user_id"));
				noticeDto.setSubject(rs.getString("subject"));
				noticeDto.setContent(rs.getString("content"));
				noticeDto.setRegtime(rs.getString("USER_REGISTER_DATE"));
			}
		} finally {
			DBManager.close(rs, pstmt, conn);
		}
		return noticeDto;
	}

	@Override
	public void modifyArticle(NoticeDto noticeDto) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnect();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("update notice \n");
			insertMember.append("set content = ? \n");
			insertMember.append("where articleno = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, noticeDto.getContent());
			pstmt.setInt(2, noticeDto.getArticleNo());
			pstmt.executeUpdate();
		} finally {
			DBManager.close(pstmt, conn);
		}

	}

	@Override
	public void deleteArticle(int articleNo) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnect();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("delete from notice \n");
			insertMember.append("where articleno = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setInt(1, articleNo);
			pstmt.executeUpdate();
		} finally {
			DBManager.close(pstmt, conn);
		}
	}

	@Override
	public int boardFileInsert(NoticeFileDto boardFileDto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		int ret = -1;

		try {
			con = DBManager.getConnect();

			StringBuilder sb = new StringBuilder();
			sb.append("INSERT INTO NOTICE_FILE ( BOARD_ID, FILE_NAME, FILE_SIZE, FILE_CONTENT_TYPE, FILE_URL ) ");
			sb.append(" VALUES ( ?, ?, ?, ?, ? ) ");

			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, boardFileDto.getBoardId());
			pstmt.setString(2, boardFileDto.getFileName());
			pstmt.setLong(3, boardFileDto.getFileSize());
			pstmt.setString(4, boardFileDto.getFileContentType());
			pstmt.setString(5, boardFileDto.getFileUrl());

			ret = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(rs, pstmt, con);
		}

		return ret;

	}

	@Override
	public List<NoticeFileDto> NoticeDetailFileList(int articleNo) {

		List<NoticeFileDto> list = new ArrayList<NoticeFileDto>();

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DBManager.getConnect();

			StringBuilder sb = new StringBuilder();
			sb.append("SELECT BOARD_ID, FILE_ID, FILE_NAME, FILE_SIZE, FILE_CONTENT_TYPE, FILE_URL, REG_DT ");
			sb.append("  FROM NOTICE_FILE ");
			sb.append(" WHERE BOARD_ID = ? ");

			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, articleNo);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				NoticeFileDto NoticeFileDto = new NoticeFileDto();
				NoticeFileDto.setBoardId(rs.getInt("BOARD_ID"));
				NoticeFileDto.setFileId(rs.getInt("FILE_ID"));
				NoticeFileDto.setFileName(rs.getString("FILE_NAME"));
				NoticeFileDto.setFileSize(rs.getInt("FILE_SIZE"));
				NoticeFileDto.setFileContentType(rs.getString("FILE_CONTENT_TYPE"));
				NoticeFileDto.setFileUrl(rs.getString("FILE_URL"));
				// boardDto.setRegDt(rs.getDate("REG_DT"));
				// boardDto.setRegDt(rs.getDate("REG_DT").toLocalDate ());
				NoticeFileDto.setRegDt(rs.getTimestamp("REG_DT").toLocalDateTime());
				list.add(NoticeFileDto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(rs, pstmt, con);
		}

		return list;
	}

	@Override
	public List<String> NoticeFileUrlDeleteList(int articleNo) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<String> list = new ArrayList<String>();
		
		try {
			con = DBManager.getConnect();
			
			StringBuilder sb = new StringBuilder();
			sb.append("SELECT FILE_URL "); 
			sb.append("	 FROM NOTICE_FILE ");
			sb.append("	WHERE BOARD_ID = ? ");

			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, articleNo);
	
			rs = pstmt.executeQuery();

			while(rs.next()) {
				list.add(rs.getString("FILE_URL"));
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(rs, pstmt, con);
		}
		
		return list;
	}

	@Override
	public int NoticeFileDelete(int articleNo) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int ret = -1;
		
		try {
			con = DBManager.getConnect();
			
			StringBuilder sb = new StringBuilder();
			sb.append("DELETE FROM NOTICE_FILE ");
			sb.append(" WHERE BOARD_ID = ? ");

			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, articleNo);
	
			ret = pstmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(rs, pstmt, con);
		}
		
		return ret;
		
	}

	public void boardUpdate(NoticeDto noticeDto) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        int ret = -1;

        try {
            con = DBManager.getConnect();

            StringBuilder sb = new StringBuilder();
            sb.append("UPDATE NOTICE SET CONTENT = ? ");
            sb.append(" WHERE ARTICLENO = ? ");

        pstmt = con.prepareStatement(sb.toString());
        pstmt.setString(1,  noticeDto.getContent());
        pstmt.setInt(2,  noticeDto.getArticleNo());

        ret = pstmt.executeUpdate();
        
    }catch(Exception e) {
        e.printStackTrace();
    }finally {
        DBManager.close(rs, pstmt, con);
    }
    
}

	

}
