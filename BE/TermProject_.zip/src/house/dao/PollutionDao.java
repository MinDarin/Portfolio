package house.dao;

import java.util.List;

import house.dto.PollutionDto;

public interface PollutionDao {

	List<PollutionDto> getPollution(String key,String word) throws Exception;
}
