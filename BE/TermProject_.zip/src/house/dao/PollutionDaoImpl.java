package house.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import house.common.DBManager;
import house.dto.HouseDto;
import house.dto.PollutionDto;

public class PollutionDaoImpl implements PollutionDao {
	private static PollutionDaoImpl instance;

	private PollutionDaoImpl() {}

	public static PollutionDaoImpl getInstance() {
		if (instance == null)
			instance = new PollutionDaoImpl();
		return instance;
	}

	@Override
	public List<PollutionDto> getPollution(String key, String word) throws Exception {

		System.out.println("hit pol!, "+key+"/"+word);		
		ArrayList<PollutionDto> resultList = new ArrayList<PollutionDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		System.out.println("inDao "+key+"/"+word);
		
		try {
			conn = DBManager.getConnect();	
			StringBuilder sql = new StringBuilder("Select * from pollution where juso like ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1,"%"+word+"%");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				PollutionDto pollutiondto = new PollutionDto();
				pollutiondto.setNo(rs.getInt("pno"));
				pollutiondto.setPtype(rs.getString("ptype"));
				pollutiondto.setName(rs.getString("pname"));
				pollutiondto.setJuso(rs.getString("juso"));
				pollutiondto.setLat(rs.getString("lat"));
				pollutiondto.setLng(rs.getString("lng"));
				resultList.add(pollutiondto);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("에러발생");

		}
		finally {
			DBManager.close(rs, pstmt, conn);
		}
		System.out.println(resultList.size());
		return resultList;
	}
}
