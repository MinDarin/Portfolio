package house.dao;

import java.util.List;

import house.dto.RestaurantDto;

public interface RestaurantDao {
	List<RestaurantDto> getRestaurant(String key,String word) throws Exception;
}
