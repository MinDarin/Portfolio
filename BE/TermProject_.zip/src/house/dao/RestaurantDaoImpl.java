package house.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import house.common.DBManager;
import house.dto.PollutionDto;
import house.dto.RestaurantDto;

public class RestaurantDaoImpl implements RestaurantDao{

	private static RestaurantDaoImpl instance;

	private RestaurantDaoImpl() {}

	public static RestaurantDaoImpl getInstance() {
		if (instance == null)
			instance = new RestaurantDaoImpl();
		return instance;
	}

	@Override
	public List<RestaurantDto> getRestaurant(String key,String word) throws Exception {
		System.out.println("inDao res!, "+key+"/"+word);
		ArrayList<RestaurantDto> resultList = new ArrayList<RestaurantDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBManager.getConnect();	
			StringBuilder sql = new StringBuilder("Select * from ssafyweb.restaurant where juso like ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1,"%"+word+"%");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				RestaurantDto restaurantdto = new RestaurantDto();
				restaurantdto.setNo(rs.getInt("rno"));
				restaurantdto.setType(rs.getString("rtype"));
				restaurantdto.setName(rs.getString("rname"));
				restaurantdto.setJuso(rs.getString("juso"));
				restaurantdto.setLat(rs.getString("lat"));
				restaurantdto.setLng(rs.getString("lng"));
				resultList.add(restaurantdto);
			}
		}
		catch(Exception e) {
			System.out.println("에러임");
			e.printStackTrace();
		}
		finally {
			DBManager.close(rs, pstmt, conn);
		}
		System.out.println("size : "+resultList.size());
		return resultList;
	}
}
