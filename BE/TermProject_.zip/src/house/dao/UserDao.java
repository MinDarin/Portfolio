package house.dao;

import java.sql.SQLException;

import house.dto.UserDto;

public interface UserDao {
//	회원가입
	void registerMember(UserDto userDto) throws SQLException;

//	로그인
	UserDto login(String userId, String userPwd);

//	회원정보 수정을 위한 회원의 모든 정보 얻기
	UserDto getMember(String userId) throws SQLException;

//	회원정보 수정
	void modifyMember(UserDto userDto) throws SQLException;

//	회원탈퇴
	void deleteMember(String userId) throws SQLException;
}
