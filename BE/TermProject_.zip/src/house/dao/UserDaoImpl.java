package house.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import house.common.DBManager;
import house.dto.UserDto;

public class UserDaoImpl implements UserDao {

	// 싱글톤
	private static UserDao userDao;

	private UserDaoImpl() {}

	public static UserDao getUserDao() {
		if (userDao == null)
			userDao = new UserDaoImpl();
		return userDao;
	}

	@Override
	public void registerMember(UserDto userDto) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int cnt = 0;
		
		try {
			conn = DBManager.getConnect();
			
			StringBuilder insertMember = new StringBuilder();
			
			insertMember.append("insert into user (USER_ID, USER_NAME, USER_PASSWORD,  USER_EMAIL,USER_PHONE, USER_ADDRESS, USER_REGISTER_DATE) \n");
			insertMember.append("values (?, ?, ?, ?, ?, ?, now())");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, userDto.getUserId());
			pstmt.setString(2, userDto.getUserName());
			pstmt.setString(3, userDto.getUserPwd());
			pstmt.setString(4, userDto.getEmail());
			pstmt.setString(5, userDto.getPhone());
			pstmt.setString(6, userDto.getAddress());
			cnt = pstmt.executeUpdate();			
		} //오류는 메인 컨트롤러에서 처리하여 505로 출력
		finally {
			DBManager.close(pstmt,conn);
		}
	}

	@Override
	public UserDto login(String userId, String userPwd) {
		UserDto userDto = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBManager.getConnect();
			String sql = 
					"SELECT USER_SEQ, USER_ID, USER_NAME, USER_PASSWORD,  USER_EMAIL,USER_PHONE, USER_ADDRESS, USER_REGISTER_DATE " + 
					"  FROM USER WHERE USER_ID = ? and  USER_PASSWORD =?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1,  userId);
			pstmt.setString(2, userPwd);
			
			System.out.println(pstmt.toString());
			rs = pstmt.executeQuery();

			if(rs.next()) {
				userDto = new UserDto();
				userDto.setSeq(rs.getInt("USER_SEQ"));
				userDto.setUserId(rs.getString("USER_ID"));
				userDto.setUserName(rs.getString("USER_NAME"));
				userDto.setUserPwd(rs.getString("USER_PASSWORD"));
				userDto.setEmail(rs.getString("USER_EMAIL"));
				userDto.setAddress(rs.getString("USER_ADDRESS"));
				userDto.setPhone(rs.getString("USER_PHONE"));
				userDto.setJoindate(rs.getDate("USER_REGISTER_DATE"));
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(rs, pstmt, con);
		}
		
		return userDto;
	}

	@Override
	public UserDto getMember(String userId) throws SQLException {
		
		UserDto userDto = null;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBManager.getConnect();
			StringBuilder sql = new StringBuilder();
			sql.append("select USER_SEQ, USER_ID, USER_NAME, USER_PASSWORD,  USER_EMAIL,USER_PHONE, USER_ADDRESS, USER_REGISTER_DATE\n");
			sql.append("FROM USER \n");
			sql.append("WHERE USER_ID = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, userId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				userDto = new UserDto();
				userDto.setSeq(rs.getInt("USER_SEQ"));
				userDto.setUserId(rs.getString("USER_ID"));
				userDto.setUserName(rs.getString("USER_NAME"));
				userDto.setUserPwd(rs.getString("USER_PASSWORD"));
				userDto.setEmail(rs.getString("USER_EMAIL"));
				userDto.setAddress(rs.getString("USER_ADDRESS"));
				userDto.setPhone(rs.getString("USER_PHONE"));
				userDto.setJoindate(rs.getDate("USER_REGISTER_DATE"));
			}
		} finally {
			DBManager.close(rs, pstmt, conn);
		}
		return userDto;
	}

	@Override
	public void modifyMember(UserDto userDto) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnect();
			StringBuilder insertMember = new StringBuilder();

			insertMember.append("update user \n");
			insertMember.append("set USER_NAME = ?, USER_PASSWORD = ?, USER_EMAIL = ?, USER_PHONE = ?, USER_ADDRESS = ? \n");
			insertMember.append("where USER_ID = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			
			pstmt.setString(1, userDto.getUserName());
			pstmt.setString(2, userDto.getUserPwd());
			pstmt.setString(3, userDto.getEmail());
			pstmt.setString(4, userDto.getPhone());
			pstmt.setString(5, userDto.getAddress());
			pstmt.setString(6, userDto.getUserId());
			pstmt.executeUpdate();
		} finally {
			DBManager.close(pstmt, conn);
		}
	}

	@Override
	public void deleteMember(String userId) throws SQLException{
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnect();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("delete from user \n");
			insertMember.append("where USER_ID = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, userId);
			pstmt.executeUpdate();
		} finally {
			DBManager.close(pstmt, conn);
		}

	}

}
