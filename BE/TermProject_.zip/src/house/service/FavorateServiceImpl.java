package house.service;

import java.util.List;

import house.dao.PollutionDaoImpl;
import house.dao.RestaurantDaoImpl;
import house.dto.PollutionDto;
import house.dto.RestaurantDto;

public class FavorateServiceImpl implements FavoriateService {

	private static FavorateServiceImpl instance;
	private FavorateServiceImpl() {}
	public static FavorateServiceImpl getInstance() {
		if(instance == null) {
			instance = new FavorateServiceImpl();
		}
		return instance;
	}
	@Override
	public List<PollutionDto> getPollution(String key,String word) throws Exception {
		return PollutionDaoImpl.getInstance().getPollution(key,word);
	}

	@Override
	public List<RestaurantDto> getRestaurant(String key,String word) throws Exception {
		System.out.println("hit res service!");
		return RestaurantDaoImpl.getInstance().getRestaurant(key,word);
	}
}
