package house.service;

import java.util.List;

import house.dto.PollutionDto;
import house.dto.RestaurantDto;

public interface FavoriateService {
	public List<PollutionDto> getPollution(String key,String word) throws Exception;
	public List<RestaurantDto> getRestaurant(String key,String word) throws Exception;
}
