package house.service;

import java.util.List;

import house.dto.FavoriteDto;
import house.dto.HouseDto;
import house.dto.SelectDto;

public interface HouseService {
	public List<HouseDto> getInfo(String key, String word, int lmiit, int offset);
	public int getTotal(String key, String word);
	public List<SelectDto> getSelect(String key,String code);
	public void addRegion(int seq, String si, String gu, String dong);
	public List<FavoriteDto> getRegion(int seq);
	public void deleteRegion(String code);
}
