package house.service;

import java.util.List;

import house.dao.HouseDaoImpl;
import house.dto.FavoriteDto;
import house.dto.HouseDto;
import house.dto.SelectDto;

public class HouseServiceImpl implements HouseService {
	
	private static HouseServiceImpl instance;
	private HouseServiceImpl() {}
	public static HouseServiceImpl getInstance() {
		if(instance == null) {
			instance = new HouseServiceImpl();
		}
		return instance;
	}
	
	public List<HouseDto> getInfo(String key, String word, int limit, int offset){
		key = key == null ? "" : key;
		word = word == null ? "" : word;
		System.out.println("inService "+key+"/"+word);
		return HouseDaoImpl.getInstance().getInfo(key, word, limit, offset);
	} 
	
	public int getTotal(String key, String word){
		key = key == null ? "" : key;
		word = word == null ? "" : word;		
		System.out.println("inService "+key+"/"+word);
		return HouseDaoImpl.getInstance().getTotal(key, word);
	} 
	public List<SelectDto> getSelect(String key,String code) {
		System.out.println("service select"+key+"/"+code);
		return HouseDaoImpl.getInstance().getSelect(key,code);		
	}
	public void addRegion(int seq, String si, String gu, String dong) {
		HouseDaoImpl.getInstance().addRegion(seq,si,gu,dong);
	}
	public void deleteRegion(String code) {
		HouseDaoImpl.getInstance().deleteRegion(code);
	}
	public List<FavoriteDto> getRegion(int seq) {
		return HouseDaoImpl.getInstance().getRegion(seq);
	}
}
