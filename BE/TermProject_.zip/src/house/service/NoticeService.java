package house.service;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.Part;

import house.dto.NoticeDto;


public interface NoticeService {
//	글작성
	void registerArticle(NoticeDto noticeDto) throws Exception;
	
//	글목록
	List<NoticeDto> listArticle(String key, String word) throws Exception;
	
//	글수정을 위한 글얻기
	NoticeDto getArticle(int articleNo) throws Exception;
	
//	글수정
	void modifyArticle(NoticeDto noticeDto) throws Exception;
	
//	글삭제
	void deleteArticle(int articleNo, String uploadPath) throws Exception;
	
	int boardInsert(NoticeDto noticeDto, Collection<Part> parts, String uploadPath) throws Exception;

	NoticeDto boardUpdate(NoticeDto noticeDto, Collection<Part> parts, String uploadPath) throws IOException, Exception;
	
}
