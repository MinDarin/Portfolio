package house.service;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.Part;

import java.io.File;
import org.apache.commons.io.FilenameUtils;

import house.dao.NoticeDaoImpl;
import house.dto.NoticeFileDto;
import house.dto.NoticeDto;

public class NoticeServiceImpl implements NoticeService {

	// 싱글톤 패턴
	private static NoticeService noticeService;

	private NoticeServiceImpl() {
	}

	public static NoticeService getNoticeService() {
		if (noticeService == null) {
			noticeService = new NoticeServiceImpl();
		}
		return noticeService;
	}

	@Override
	public void registerArticle(NoticeDto noticeDto) throws Exception {
		NoticeDaoImpl.getNoticeDao().registerArticle(noticeDto);
	}

	@Override
	public List<NoticeDto> listArticle(String key, String word) throws Exception {
		key = key == null ? "" : key;
		word = word == null ? "" : word;
		return NoticeDaoImpl.getNoticeDao().listArticle(key, word);
	}

	@Override
	public NoticeDto getArticle(int articleNo) throws Exception {

		NoticeDto dto = NoticeDaoImpl.getNoticeDao().getArticle(articleNo);
		List<NoticeFileDto> fileList = NoticeDaoImpl.getNoticeDao().NoticeDetailFileList(articleNo);
		dto.setFileList(fileList);
		return dto;
	}

	@Override
	public void modifyArticle(NoticeDto noticeDto) throws Exception {
		NoticeDaoImpl.getNoticeDao().modifyArticle(noticeDto);
	}

	@Override
	public void deleteArticle(int articleNo,String uploadPath) throws Exception {
			List<String> fileUrlList = NoticeDaoImpl.getNoticeDao().NoticeFileUrlDeleteList(articleNo);
			for(String fileUrl : fileUrlList) {
				File file = new File(uploadPath + File.separator, fileUrl);
				
				if(file.exists()) {
					file.delete();
				}
			}
			
			NoticeDaoImpl.getNoticeDao().NoticeFileDelete(articleNo);

			NoticeDaoImpl.getNoticeDao().deleteArticle(articleNo);

		
	}

	String uploadFolder = "upload";

	@Override
	public int boardInsert(NoticeDto noticeDto, Collection<Part> parts, String uploadPath) throws Exception {
		int boardId = NoticeDaoImpl.getNoticeDao().registerArticle(noticeDto);

		File uploadDir = new File(uploadPath + File.separator + uploadFolder);
		if (!uploadDir.exists())
			uploadDir.mkdir();

		System.out.println("parts.size() " + parts.size());
		System.out.println("upload path  " + uploadPath + File.separator + uploadFolder);
		// 첨부 파일 여러개 고려
		for (Part part : parts) {
			String fileName = getFileName(part);
			System.out.println("fileName : " + fileName);
			if ("".equals(fileName))
				continue;

			// Random File Id
			UUID uuid = UUID.randomUUID();

			// file extension
			String extension = FilenameUtils.getExtension(fileName); // vs FilenameUtils.getBaseName()

			String savingFileName = uuid + "." + extension;

			part.write(uploadPath + File.separator + uploadFolder + File.separator + savingFileName);

			// Table Insert
			NoticeFileDto boardFileDto = new NoticeFileDto();
			boardFileDto.setBoardId(boardId);
			boardFileDto.setFileName(fileName);
			boardFileDto.setFileSize(part.getSize());
			boardFileDto.setFileContentType(part.getContentType());
			String boardFileUrl = uploadFolder + "/" + savingFileName;
			boardFileDto.setFileUrl(boardFileUrl);

			NoticeDaoImpl.getNoticeDao().boardFileInsert(boardFileDto);
		}

		return boardId;
	}

	// utility method
	private String getFileName(Part part) {
		for (String content : part.getHeader("content-disposition").split(";")) {
			if (content.trim().startsWith("filename"))
				return content.substring(content.indexOf("=") + 2, content.length() - 1);
		}
		return "";
	}

	
	@Override
	public NoticeDto boardUpdate(NoticeDto noticeDto, Collection<Part> parts, String uploadPath) throws Exception {
		
		NoticeDaoImpl.getNoticeDao().boardUpdate(noticeDto);
		NoticeDto dto = NoticeDaoImpl.getNoticeDao().getArticle(noticeDto.getArticleNo());
		
		File uploadDir = new File(uploadPath + File.separator + uploadFolder);
		if (!uploadDir.exists()) uploadDir.mkdir();
		
		// 새로운 파일이 첨부되어 있으면 기존 파일을 삭제해야 하는데 삭제 작업을 loop 에서 매번 하지 않고 한번 만 하기 위한 변수
		boolean isFileDeleted = false;
		
		// 첨부파일 여러개 고려
		for ( Part part : parts ) {
		    String fileName = getFileName(part);
	    
		    if("".equals(fileName)) continue;
		    
		    // 새로운 파일이 첨부되어 있으면
		    if( ! isFileDeleted ) {
		    	
		    	// 물리 파일 삭제
		    	// 첨부파일 여러개 고려
		    	List<String> fileUrlList = NoticeDaoImpl.getNoticeDao().NoticeFileUrlDeleteList(noticeDto.getArticleNo());

				for(String fileUrl : fileUrlList) {

					File file = new File(uploadPath + File.separator, fileUrl);
					if(file.exists()) {
						file.delete();
					}
				}
				
				// 테이블 파일 삭제
				NoticeDaoImpl.getNoticeDao().NoticeFileDelete(noticeDto.getArticleNo());
		    	isFileDeleted = true;
		    }
		    
		    //Random File Id
			UUID uuid = UUID.randomUUID();
			
			//file extension
			String extension = FilenameUtils.getExtension(fileName); // vs FilenameUtils.getBaseName()
			
			String savingFileName = uuid + "." + extension;
			
		    part.write(uploadPath + File.separator + uploadFolder + File.separator + savingFileName);
		    
		    // Table Insert
		    NoticeFileDto noticeFileDto = new NoticeFileDto();
		    noticeFileDto.setBoardId(dto.getArticleNo());
		    noticeFileDto.setFileName(fileName);
		    noticeFileDto.setFileSize(part.getSize());
			noticeFileDto.setFileContentType(part.getContentType());
			String boardFileUrl = uploadFolder + "/" + savingFileName;
			noticeFileDto.setFileUrl(boardFileUrl);

			NoticeDaoImpl.getNoticeDao().boardFileInsert(noticeFileDto);
		}
		return dto;
	}

}
