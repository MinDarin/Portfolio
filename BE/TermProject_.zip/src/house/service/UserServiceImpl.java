package house.service;

import java.sql.SQLException;

import house.dao.UserDao;
import house.dao.UserDaoImpl;
import house.dto.UserDto;

public class UserServiceImpl implements UserService {

	//싱글톤 패턴
		private static UserService userService;
		private UserServiceImpl(){}
		
		public static UserService getUserService() {
			if(userService == null) {
				userService = new UserServiceImpl();
			}
			return userService;
		}
		
	@Override
	public void registerMember(UserDto userDto) throws Exception {
		UserDaoImpl.getUserDao().registerMember(userDto);
	}

	@Override
	public UserDto login(String userId, String userPwd) {
		return UserDaoImpl.getUserDao().login(userId, userPwd);
	}

	@Override
	public UserDto getMember(String userId) throws SQLException {
		return UserDaoImpl.getUserDao().getMember(userId);
	}

	@Override
	public void modifyMember(UserDto userDto) throws SQLException {
		UserDaoImpl.getUserDao().modifyMember(userDto);
	}

	@Override
	public void deleteMember(String userId) throws SQLException{
		UserDaoImpl.getUserDao().deleteMember(userId);
		
	}

}
