<template>
  <div id="app">
    <nav-header></nav-header>
    <router-view />

    <home-footer></home-footer>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"
      ><i class="bi bi-arrow-up-short"></i
    ></a>
  </div>
</template>

<script>
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import NavHeader from "@/views/NavHeader.vue";
import HomeFooter from "@/views/Footer.vue";

export default {
  name: "App",
  components: {
    NavHeader,
    HomeFooter,
  },
};
</script>

<style>
@import "https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i";
/* Vendor CSS Files */
@import "./assets/vendor/animate.css/animate.min.css";
@import "./assets/vendor/aos/aos.css";
@import "./assets/vendor/bootstrap/css/bootstrap.min.css";
@import "./assets/vendor/bootstrap-icons/bootstrap-icons.css";
@import "./assets/vendor/boxicons/css/boxicons.min.css";
@import "./assets/vendor/glightbox/css/glightbox.min.css";
@import "./assets/vendor/swiper/swiper-bundle.min.css";

/* Template Main CSS File */
@import "./assets/css/style.css";

.mainSection{
  height : 850px;
}
</style>
