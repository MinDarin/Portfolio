import Vue from "vue";
import VueRouter from "vue-router";

import Home from "../views/Home.vue";
import HouseDeal from "@/views/HouseDeal.vue";
import Login from "@/views/Login.vue";
import UserInfo from "@/views/UserInfo.vue";
import UserRegist from "@/views/UserRegist.vue";
import NoticeMain from "@/views/notice/NoticeMain.vue";
import NoticeDetail from "@/views/notice/NoticeDetail.vue";
import NoticeInsert from "@/views/notice/NoticeInsert.vue";
import NoticeUpdate from "@/views/notice/NoticeUpdate.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/notice",
    name: "Notice",
    component: NoticeMain,
  },
  {
    path: "/house-deal",
    name: "HouseDeal", 
    component: HouseDeal,
  },
  {  
    path: "/login",
    name: "Login",
    component: Login,
  },
  {
    path: "/user-info",
    name: "UserInfo",
    component: UserInfo,
  },
  {
    path: "/user-regist",
    name: "UserRegist",
    component: UserRegist,
  },
  {
    path: "/notice/:id",
    name: "NoticeDetail",
    component: NoticeDetail,
  },
  {
    path: "/notice-insert",
    name: "NoticeInsert",
    component: NoticeInsert,
  },
  {
    path: "/notice-update",
    name: "NoticeUpdate",
    component: NoticeUpdate,
  },


];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
