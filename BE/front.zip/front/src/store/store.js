import Vue from 'vue';
import Vuex from 'vuex';
//import createPersistedState from 'vuex-persistedstate';
Vue.use(Vuex);
import http from "@/util/http-common.js";

export default new Vuex.Store({

  // plugins: [
  //   createPersistedState(),
  // ],
  state: {
    curLat: 37.50143429092664,
    curLng: 127.03954834687455,
    
    selectedComponent: "list",
    mapComponent: "list",
    typeList: ["빌라", "아파트", "원룸", "오피스텔"],
    dealList: [
    ],  // 우측 한 페이지씩만 가져옴
    totalSimpleList :[], //마커 찍기 위해 받아오는 전체 리스트
    dealOne: {
      info: "",
      dealHistory: "",  
    },
    dealIndex: 0,
    selectedMarker : "",

    //pagenation
    deal: {
      limit: 5,
      offset: 0,
      listRowCount: 5,
      pageLinkCount: 10,
      currentPageIndex: 1,    
      totalListItemCount: 0,
      word: '',
      key : '',
      },
    store: {
      lastIndex: -1,
      storeList: [],
      checked: [],
      markers: [[],[],[]],
    },
    notice : {
      // 페이징
      limit: 5,
      offset: 0,
      listRowCount: 5,
      pageLinkCount: 10,
      currentPageIndex: 1,    
      totalListItemCount: 0,
      // 검색
      searchWord : '',
      // 현재 게시글
      noticeId: 0,
      title: '',
      content: '',
      userName: '',
      regDt: {},
      readCount: 0,
      fileList: [],
      isOwner: false
    },

    login : {
      isLogin : false,
      userEmail : '',
      userName : '',
      userProfileImageUrl : '',
      userRole : '',
      userId: '',
      userPhone: '',
      userAddress: '',
    }
  },
  mutations: {
    SET_BOARD_MOVE_PAGE(state, pageIndex) {
      state.deal.offset = (pageIndex - 1) * state.deal.listRowCount;
      state.deal.currentPageIndex = pageIndex;
    },
    SET_BOARD_LIST(state, list) {
      state.dealList = list
    },
    SET_TOTAL_DEAL_LIST(state, list) {
      state.totalSimpleList = list
    },
    SET_BOARD_TOTAL_LIST_ITEM_COUNT(state, count) {
      state.deal.totalListItemCount = count
    },
    SET_DEALINFO_ONE(state, list) {
      state.dealOne.dealHistory = list;
      state.dealOne.dealHistory.reverse(); 
    },
    SET_NOTICE_DETAIL(state, payload) {
      state.notice.noticeNo = payload.dto.noticeNo;
      state.notice.title = payload.dto.title;
      state.notice.content = payload.dto.content;
      state.notice.userName = payload.dto.userName;
      state.notice.regDt = payload.dto.regDt;
      state.notice.fileList = payload.dto.fileList;
      
      state.notice.readCount = payload.dto.readCount;
      state.notice.isOwner = payload.isOwner;
    },

    SET_NOTICE_MOVE_PAGE(state, pageIndex) {
      state.notice.offset = (pageIndex - 1) * state.notice.listRowCount;
      state.notice.currentPageIndex = pageIndex;
    },
    SET_NOTICE_TOTAL_LIST_ITEM_COUNT(state, count) {
      state.notice.totalListItemCount = typeof count == "undefined" ? 0 : count;
    },

    SET_LOGIN(state, payload) {
      state.login.isLogin = payload.isLogin;
      state.login.userName = payload.userName;
      state.login.userRole = payload.userRole;

      state.login.userId = payload.userId;
      state.login.userPhone = payload.userPhone;
      state.login.userEmail = payload.userEmail;
      state.login.userAddress = payload.Address;
    },
    SET_LOGOUT(state) {
      state.login.isLogin = false;
      state.login.userName = '';
      state.login.userRole = '';

      state.login.userId = '';
      state.login.userPhone = '';
      state.login.userEmail = '';
      state.login.userAddress = '';
    },

    SET_STORE(state, list) {
      console.log("list len" + list.length);
      var tempList = [];
      for (let i = 0; i < list.length; i++) {
        if (state.store.lastIndex == -1) {
          state.store.lastIndex = list[i].code;
          tempList.push(list[i]);
        }
        else if (state.store.lastIndex != list[i].code) {
          state.store.storeList.push(tempList);
          tempList = [];
          state.store.lastIndex = list[i].code;
          tempList.push(list[i]);
        }
        else {
          tempList.push(list[i])
        }
      }
      if (tempList != null)
        state.store.storeList.push(tempList);
      console.log("splited")
      console.log(state.store.storeList);
    }
  },
  actions: {
    boardList(context){
        //axios 동작 와야함
        http.get(
          "/house-deals",
          {
            // get query string
            params: {
              limit: this.state.deal.limit,
              offset: this.state.deal.offset,
              word: this.state.deal.word,
              key : this.state.deal.key,
            }
          })
          .then(({ data }) => {
            console.log(data);
            context.commit('SET_BOARD_LIST', data.resultList);
            context.commit( 'SET_BOARD_TOTAL_LIST_ITEM_COUNT', data.count );
        });  
    },
    dealTotalList(context) {
      //axios 동작 와야함
      http.get("/house-deals/total"
        ,{
          params: {
            key: this.state.deal.key,
            word: this.state.deal.word,
          }
      })
        .then(({ data }) => {
          console.log(data);
          context.commit( 'SET_TOTAL_DEAL_LIST', data);
      });  
    },
    getDealInfo(context, dealNo) {
      console.log("dealNo" + dealNo)
      http.get("/house-deals/dealinfo", {
        params: {
          dealNo: dealNo,
        }
      }).then(({ data }) => {
        console.log(data);
        context.commit('SET_DEALINFO_ONE', data);
        }
      )
    },


    getConvInfo(context, infoNo) {
      context.state.store.lastIndex = -1;
      context.state.store.storeList = [];
      context.state.store.markers =  [[],[],[]],
      http.get("/stores/near", {
        params: {
          houseinfoNo: infoNo,
        }
      }).then(({ data }) => {
        console.log("list");
        console.log(data);
        context.commit('SET_STORE', data.list);
        }
      )
    }

  },
})