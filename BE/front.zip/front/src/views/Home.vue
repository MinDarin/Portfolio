<template>
      <div id="carouselExampleCaptions" class="carousel slide mainSection" data-bs-ride="carousel">
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
          </div>
          <div class="carousel-inner">
            <div :class="['carousel-item', {'active' : idx == 1 }]" v-for="(image, idx) in slidshow" :key="image" >
              <img :src="require('@/assets/img/slide/' + image)" class="d-block big" alt="...">
              <div class="carousel-caption d-none d-md-block">
                <h5>First Home Picture</h5>
                <p>Well Come to Sweet Home</p>
              </div>
            </div>
            
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span class="carousel-control-prev-icon bx bx-left-arrow" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span class="carousel-control-next-icon bx bx-right-arrow" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: "Home",
  data(){
    return {
      slidshow : [
        "slide-1.jpg",
        "slide-2.jpg",
        "slide-3.jpg",
      ]
    }
  }
};
</script>

<style>
  .big {
    width: 100%;
    height: 70vh;
    overflow: hidden;
    position: relative;
    padding: 0;
  }
  
</style>