<template>
  <div id="housedeal" class="row" style="min-height: 1000px">
    <div class="col-9 card mb-4 shadow" id="map">
      <div></div>
    </div>

    <div id="left-bar" class="col-3">
      <form class="form-inline">
        <div class="content mb-3 shadow" style="align-items: center">
          <div class="row ml-3">
            <div>
              <nav class="navbar navbar-expand-sm bg-white navbar-dark">
                <div class="dropdown-header col-3">
                  <select class="form-control" name="key" id="key" v-model="key">
                    <option value="address">동</option>
                    <option value="AptName">아파트</option>
                  </select>
                </div>
                <div class="col-7">
                  <input
                    class="form-control mr-sm-2"
                    type="text"
                    placeholder="동, 이름으로 검색"
                    name="toggleSearch"
                    id="toggleSearch"
                    v-model="word"
                    @keyup.enter="btnSearch"
                  />
                </div>
                <div class="col-2">
                  <div
                    class="btn"
                    style="background-color: #fd5c28; color: white"
                    @click="btnSearch"
                  >
                    검 색
                  </div>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </form>

      <div class="card shadow mb-3">
        <div style="min-height: 1000px; text-align: left">
          <component
            v-bind:is="this.$store.state.selectedComponent"
            v-on:moveCenter="moveCenter"
            v-on:hover="hover"
            v-on:hout="hout"
          ></component>
          <!--    <div id="paginationWrapper"></div> -->
        </div>
      </div>
    </div>
    <!-- 상단 검색 박스 -->
    <!-- Map Start -->
  </div>
</template>

<script>
//import http from "@/util/http-common";
import list from "@/views/houseDealInfo/HouseDealList.vue";
import one from "@/views/houseDealInfo/HouseDealDetail.vue";
export default {
  name: "HouseDeal",
  components: {
    list,
    one,
  },
  data: function () {
    return {
      key: "address",
      word: "",
      map: "",
      center: {
        La: "37.50143429092664",
        Ma: "127.03954834687455",
      },
      markers: [],
      level: "3",
      depth: 0, //2 1 0 으로 구분할거임
      curAddress: ["서울", "강남구", "역삼동"],
    };
  },
  watch: {
    key: function () {
      this.$store.state.deal.key = this.key;
    },
    word: function () {
      this.$store.state.deal.word = this.word;
    },
    getList() {
      window.kakao && window.kakao.maps ? this.initMap() : this.addKakaoMapScript();
      //this.initMap();
    },
    convCheck() {
      this.drawConvMark();
    },
    level: function () {
      console.log(this.level);
      var curDepth;
      if (this.level >= 7) {
        curDepth = 2;
      } else if (this.level < 7 && this.level > 3) {
        curDepth = 1;
      } else {
        curDepth = 0;
      }
      if (curDepth != this.depth) {
        //레벨 달라 졌으니 검색 로직 수행
        this.depth = curDepth;
        this.searchTotal();
      }
    },
    center: function () {
      this.changeCenter();
    },
  },
  computed: {
    getList() {
      return this.$store.state.totalSimpleList;
    },
    convCheck() {
      return this.$store.state.store.checked;
    },
  },
  created() {
    //    this.$store.dispatch("boardList");
    this.searchTotal();
  },
  methods: {
    drawConvMark() {
      for (let i = 0; i <= 2; i++) {
        var imageSrc = require("@/assets/img/markers/marker" + (i + 1) + ".png");
        var imageSize = new kakao.maps.Size(20, 20);
        var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);
        if (this.$store.state.store.checked.includes(i)) {
          if (this.$store.state.store.markers[i] == "") {
            var curList = this.$store.state.store.storeList[i];
            for (let j = 0; j < curList.length; j++) {
              this.$store.state.store.markers[i].push(
                new kakao.maps.Marker({
                  position: new kakao.maps.LatLng(curList[j].lat, curList[j].lng),
                  image: markerImage,
                })
              );
              this.$store.state.store.markers[i][j].setMap(this.map);
            }
          }
        } else {
          if (this.$store.state.store.markers[i] != "") {
            for (let j = 0; j < this.$store.state.store.markers[i].length; j++) {
              this.$store.state.store.markers[i][j].setMap(null);
              this.$store.state.store.markers[i][j] = "";
            }
            this.$store.state.store.markers[i].splice(0, this.$store.state.store.markers[i].length);
          }
        }
      }
    },
    hover(index) {
      var imageSrc = "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png";
      var imageSize = new kakao.maps.Size(40, 60);
      var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);
      console.log(this.$store.state.dealList[index]);
      this.$store.state.selectedMarker = new kakao.maps.Marker({
        position: new kakao.maps.LatLng(
          this.$store.state.dealList[index].lat,
          this.$store.state.dealList[index].lng
        ),
        image: markerImage,
      });

      this.$store.state.selectedMarker.setMap(this.map);

      var moveLatLon = new kakao.maps.LatLng(
        this.$store.state.dealList[index].lat,
        this.$store.state.dealList[index].lng
      );

      this.map.panTo(moveLatLon);
    },
    hout() {
      this.$store.state.selectedMarker.setMap(null);
    },
    searchTotal() {
      //레벨에 따라 검색 범위 정하던가 해야함(address 파싱해야함.)
      console.log("cur addr" + this.curAddress);
      var paramAddr;
      switch (this.depth) {
        case 2:
          paramAddr = this.curAddress[0] + "특별시";
          break;
        case 1:
          paramAddr = this.curAddress[0] + "특별시 " + this.curAddress[1];
          break;
        case 0:
          paramAddr =
            this.curAddress[0] + "특별시 " + this.curAddress[1] + " " + this.curAddress[2];
          break;
      }
      console.log(paramAddr);
      this.$store.state.deal.key = "address";
      this.$store.state.deal.word = paramAddr;

      this.$store.dispatch("dealTotalList");
      //바뀔 때 우측 내용도 바꿔보자
      this.word = paramAddr;
      this.$store.dispatch("boardList");
    },
    // drag() {
    //   var curCenter = this.map.getCenter();
    //   console.log(curCenter);
    //   console.log(
    //     "lat diff : " +
    //       (this.center.La - curCenter.La) +
    //       "\n lng diff : " +
    //       (this.center.Ma - curCenter.Ma)
    //   );
    //   //얼마 이상 차이나면 드래그로 판정해서 다음작업
    //   this.center = curCenter;
    //   this.changeCenter();
    // },
    // onWheel() {
    //   this.level = this.map.getLevel();
    // },
    changeCenter() {
      var geocoder = new kakao.maps.services.Geocoder();
      var tempAddress = [];
      let $this = this;
      geocoder.coord2Address(this.center.La, this.center.Ma, function (result, status) {
        console.log(result);
        console.log(status === kakao.maps.services.Status.OK);
        if (status === kakao.maps.services.Status.OK) {
          tempAddress[0] = result[0].address.region_1depth_name;
          tempAddress[1] = result[0].address.region_2depth_name;
          tempAddress[2] = result[0].address.region_3depth_name;
        }
        // var StempAddress = tempAddress[0] + "특별시 " + tempAddress[1] + " " + tempAddress[2];
        // console.log("Sadd" + StempAddress);
        if (
          !(
            $this.curAddress[0] == tempAddress[0] &&
            $this.curAddress[1] == tempAddress[1] &&
            $this.curAddress[2] == tempAddress[2]
          )
        ) {
          //여기서 기존에 저장되어 있던 주소랑 StempAddress 비교해서 다르면
          //데이터 받아오기

          $this.curAddress = tempAddress;
          $this.searchTotal();

          //동 이동시 페이지네이션 1페이지로 바꿔줘야함.
          $this.$store.state.deal.currentPageIndex = 1;
        }
      });
    },
    btnSearch() {
      this.$store.state.deal.currentPageIndex = 1;
      //검색 버튼 클릭시..
      this.$store.dispatch("boardList");
    },
    addKakaoMapScript() {
      const script = document.createElement("script");
      /* global kakao */
      script.onload = () => kakao.maps.load(this.initMap);
      script.src =
        "http://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=968a4feff63e4692f6229410c2a55915";
      document.head.appendChild(script);
    },
    initMap() {
      console.log("run map init");
      if (this.map == null || this.map == "") {
        var container = document.getElementById("map"); //지도를 담을 영역의 DOM 레퍼런스
        var options = {
          //지도를 생성할 때 필요한 기본 옵션
          center: new kakao.maps.LatLng(this.center.La, this.center.Ma), //지도의 중심좌표.
          level: 3, //지도의 레벨(확대, 축소 정도)
        };
        this.map = new kakao.maps.Map(container, options); //지도 생성 및 객체 리턴
        // this.level = this.map.getLevel();
        // this.center = this.map.getCenter();

        var mapTypeControl = new kakao.maps.MapTypeControl();
        this.map.addControl(mapTypeControl, kakao.maps.ControlPosition.TOPRIGHT);

        var $this = this;
        kakao.maps.event.addListener(this.map, "center_changed", function () {
          // 지도의  레벨을 얻어옵니다
          $this.level = $this.map.getLevel();
          // 지도의 중심좌표를 얻어옵니다
          $this.center = $this.map.getCenter();
        });

        // 지도에 컨트롤을 추가해야 지도위에 표시됩니다
        // kakao.maps.ControlPosition은 컨트롤이 표시될 위치를 정의하는데 TOPRIGHT는 오른쪽 위를 의미합니다
        this.map.addControl(mapTypeControl, kakao.maps.ControlPosition.TOPRIGHT);

        // 지도 확대 축소를 제어할 수 있는  줌 컨트롤을 생성합니다
        var zoomControl = new kakao.maps.ZoomControl();
        this.map.addControl(zoomControl, kakao.maps.ControlPosition.RIGHT);
      }
      var clusterer = new kakao.maps.MarkerClusterer({
        map: this.map, // 마커들을 클러스터로 관리하고 표시할 지도 객체
        averageCenter: true, // 클러스터에 포함된 마커들의 평균 위치를 클러스터 마커 위치로 설정
        minLevel: 2, // 클러스터 할 최소 지도 레벨
      });
      //      var curList = this.$store.state.totalSimpleList;
      // var positions = [];
      // //      var positions = this.$store.state.deal.flagPosition;
      // for (let i = 0; i < curList.length; i++) {
      //   positions[i] = {
      //     title: curList[i].AptName,
      //     latlng: new kakao.maps.LatLng(curList[i].lat, curList[i].lng),
      //   };
      // }
      //var imageSrc = "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png";

      // for (var i = 0; i < positions.length; i++) {
      //   // 마커 이미지의 이미지 크기 입니다
      //   var imageSize = new kakao.maps.Size(40, 65);

      //   // 마커 이미지를 생성합니다
      //   var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);

      //   // 마커를 생성합니다
      //   var marker = new kakao.maps.Marker({
      //     map: map,
      //     position: positions[i].latlng, // 마커를 표시할 위치
      //     title: positions[i].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
      //     image: markerImage, // 마커 이미지
      //   });
      //   marker.setMap(map);
      // }
      var curList = this.$store.state.totalSimpleList;
      //기존 마커 지우기
      for (let i = 0; i < this.markers.length; i++) {
        this.markers[i].setMap(null);
      }
      //마커 그리기
      var imageSrc = "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/marker_red.png";
      // 마커 이미지의 이미지 크기 입니다
      var imageSize = new kakao.maps.Size(24, 35);
      // 마커 이미지를 생성합니다
      var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);
      for (let i = 0; i < curList.length; i++) {
        this.markers[i] = new kakao.maps.Marker({
          position: new kakao.maps.LatLng(curList[i].lat, curList[i].lng),
          image: markerImage,
        });
      }
      clusterer.addMarkers(this.markers);
    },
    moveCenter() {},
  },
};
</script>

<style>
.map {
  width: 100%;
  height: 600px;
}
</style>
