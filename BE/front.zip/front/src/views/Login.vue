<template>
  <div class="mainSection"
    :style="{
      backgroundImage: 'url(' + require('@/assets/img/slide/slide-1.jpg') + ')',
      'background-repeat': 'no-repeat',
      'background-position': 'center center',
      'background-size': 'cover',
    }"
  >
    <!-- <img :src="require('@/assets/img/slide/slide-1.jpg')" class="d-block big" alt="..."> -->
    <div class="login-page">
      <div class="form">
        <div class="login">
          <div class="login-header">
            <h3>LOGIN</h3>
            <p>Please enter your credentials to login.</p>
          </div>
        </div>
        <form class="login-form">
          <input v-model="userId" type="text" placeholder="username" />
          <input v-model="userPassword" type="password" placeholder="password" />
          <button @click.prevent="login">login</button>
          <p class="message">
            Not registered? <router-link to="/user-regist">Create an account</router-link>
          </p>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import VueAlertify from "vue-alertify";
Vue.use(VueAlertify);

import http from "@/util/http-common.js";
export default {
  name: "Login",
  data() {
    return {
      userId: "",
      userPassword: "",
    };
  },
  methods: {
    login() {
      http
        .post("/users/login", {
          userId: this.userId,
          userPassword: this.userPassword,
        })
        .then(({ data }) => {
          console.log(data);

          this.$store.commit("SET_LOGIN", {
            isLogin: true,
            userName: data.userName,
            userRole: data.userRole,
            userId: data.userId,
            userPhone: data.userPhone,
            userAddress: data.userAddres,
            userEmail : data.userEmail,
          });
          this.$alertify.success(data.userName + "님 환영합니다!");
          this.$router.push("/");
        })
        .catch((error) => {
          console.log(error);
          this.$alertify.error("이메일 또는 비밀번호를 확인하세요.");
        });
    },
  },
};
</script>

<style>
@import url(https://fonts.googleapis.com/css?family=Roboto:300);
header .header {
  background-color: #fff;
  height: 45px;
}
header a img {
  width: 134px;
  margin-top: 4px;
}
.login-page {
  width: 360px;
  padding: 8% 0 0;
  margin: auto;
}
.login-page .form .login {
  margin-top: -31px;
  margin-bottom: 26px;
}
.login-page .form {
  position: relative;
  z-index: 1;
  background: #ffffff;
  max-width: 360px;
  margin: 0 auto;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.login-page .form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.login-page .form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background-color: #f03c02;
  background-image: linear-gradient(45deg, #f03c02, #1e1915);
  width: 100%;
  border: 0;
  padding: 15px;
  color: #ffffff;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.login-page .form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.login-page .form .message a {
  color: #f03c02;
  text-decoration: none;
}
</style>
