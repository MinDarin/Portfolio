<template>
  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex justify-content-between">
      <div class="logo">
        <h1 class="text-light"><router-link to="/">Happy House</router-link></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><router-link to="/">Home</router-link></li>
          <li><router-link to="/notice">공지사항</router-link></li>
          <li><router-link to="/house-deal">아파트 매매가 정보</router-link></li>
          <li v-if="!$store.state.login.isLogin"><router-link to="/login">로그인</router-link></li>
          <li v-if="!$store.state.login.isLogin"><router-link to="/user-regist">회원가입</router-link></li>
          <li v-if="$store.state.login.isLogin"><router-link to="/user-info">회원 정보</router-link></li>
          <li v-if="$store.state.login.isLogin" @click="logoutForm"><a>로그아웃</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <!-- .navbar -->
    </div>
  </header>
  <!-- End Header -->
</template>

<script>
import http from "@/util/http-common.js";
import Vue from 'vue';
import VueAlertify from 'vue-alertify'; 
Vue.use(VueAlertify);

export default {
  name: "NavHeader",
  methods : {
    logoutForm () {
      var $this = this;
      this.$alertify
        .alert("알림")
        .set({
          'invokeOnCloseOff': true,
          'message' : " 로그아웃 하시겠습니까? ",
          'onok': function(){
            $this.logout();
        }});
    },
    logout() {
      http.post('/users/logout')
        .then( () => {
          this.$store.commit('SET_LOGOUT');
          this.$alertify.success('로그아웃 성공하였습니다.');
        });
    },
  },
};
</script>