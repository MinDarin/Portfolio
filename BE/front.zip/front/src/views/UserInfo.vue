<template>
  <div class="mainSection" :style="{'backgroundImage': 'url(' + require('@/assets/img/slide/slide-3.jpg') + ')', 'background-repeat': 'no-repeat', 'background-position': 'center center', 'background-size': 'cover' }">
    <div class="info-page">
      <div class="container myC form">
        <form id="userinfoform" method="post" action="">
          <div style="font-size: 20px" class="mb-5 mt-5">
            <b>회원 정보 조회</b>
          </div>
          <div class="mb-3">
            <label for="InputID" class="form-label">ID (아이디는 변경 불가합니다.)</label>
            <input
              type="text"
              class="form-control check"
              id="InputID"
              name="id"
              aria-describedby="IDHelp"
              info="아이디"
              :value="userId"
              readonly="true"
            />
            <div id="IDHelp" class="form-text helper">&nbsp;</div>
          </div>
  
          <div class="mb-3">
            <label for="InputPW" class="form-label">Password</label>
            <input
              type="password"
              class="form-control check"
              id="InputPW"
              aria-describedby="PWHelp"
              v-model="userPassword"
              name="pwd"
              info="비밀번호"
            />
            <div id="PWHelp" class="form-text helper">&nbsp;</div>
          </div>

          <div class="mb-3">
            <label for="InputName" class="form-label">이름</label>
            <input
              type="text"
              class="form-control check"
              id="InputName"
              v-model="userName"
              name="name"
              aria-describedby="NameHelp"
              info="이름"
            />
            <div id="NameHelp" class="form-text helper">&nbsp;</div>
          </div>

          <div class="mb-3">
            <label for="InputNumber" class="form-label">전화번호</label>
            <input
              type="text"
              class="form-control check"
              id="InputNumber"
              aria-describedby="NumberHelp"
              v-model="userPhone"
              name="phone"
              info="전화번호"
            />
            <div id="NumberHelp" class="form-text helper">&nbsp;</div>
          </div>

          <div class="mb-3">
            <label for="InputEmail" class="form-label">Email 주소</label>
            <input
              type="email"
              class="form-control check"
              id="InputEmail"
              aria-describedby="EmailHelp"
              v-model="userEmail"
              name="email"
              info="Email주소"
            />
            <div id="EmailHelp" class="form-text helper">&nbsp;</div>
          </div>
          <div class="mb-3">
            <label for="InputLocation" class="form-label">주소</label>
            <input
              type="text"
              class="form-control check"
              id="InputLocation"
              aria-describedby="LocationHelp"
              v-model="userAddress"
              name="address"
              info="주소"
            />
            <div id="LocationHelp" class="form-text helper">&nbsp;</div>
          </div>
          <button class="confirm">수정 완료</button>
          <br />
          <button class="delete">삭제</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "UserInfo",
  data() {
    return {
      userPassword: '1111',
      userId: this.$store.state.login.userId,
      userName: this.$store.state.login.userName,
      userPhone: this.$store.state.login.userPhone,
      userEmail: this.$store.state.login.userEmail,
      userAddress: this.$store.state.login.userAddress,
    };
  },
};
</script>
<style>
.info-page {
  width: 360px;
  padding: 8% 0 0;
  margin: auto;
}
.info-page .form {
  position: relative;
  z-index: 1;
  background: #ffffff;
  max-width: 360px;
  margin: 0 auto;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.info-page .form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.info-page .form .confirm {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background-color: #f03c02;
  background-image: linear-gradient(45deg, #f03c02, #1e1915);
  width: 100%;
  border: 0;
  padding: 15px;
  color: #ffffff;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.info-page .form .delete {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background-color: #ffffff;
  background-image: linear-gradient(45deg, #ffffff, #1e1915);
  width: 100%;
  border: 0;
  padding: 15px;
  color: #ffffff;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
</style>
