<template>
<div class="mb-3">
  <div class="bg" :style="{'backgroundImage': 'url(' + require('@/assets/img/slide/slide-4.jpg') + ')', 'background-repeat': 'no-repeat', 'background-size': 'cover'}">
      <div class="banner align-items-center text-dark text-center">
        <h1 class="">회원가입</h1>
      </div>
  </div>
    <div class="info-page">
      <div class="container myC form">
        <form id="userinfoform" method="post" action="">
          <!-- <div style="font-size: 20px" class="mb-5 mt-5">
            <b>회원 가입</b>
          </div> -->
          <div class="mb-3">
            <label for="InputID" class="form-label">ID</label>
            <input
              type="text"
              class="form-control check"
              id="InputID"
              name="id"
              aria-describedby="IDHelp"
              info="아이디"
              v-model="user.userId"
            />
            <div id="IDHelp" class="form-text helper">&nbsp;</div>
          </div>
  
          <div class="mb-3">
            <label for="InputPW" class="form-label">Password</label>
            <input
              type="password"
              class="form-control check"
              id="InputPW"
              aria-describedby="PWHelp"
              v-model="user.userPassword"
              name="pwd"
              info="비밀번호"
            />
            <div id="PWHelp" class="form-text helper">&nbsp;</div>
          </div>

          <div class="mb-3">
            <label for="InputName" class="form-label">이름</label>
            <input
              type="text"
              class="form-control check"
              id="InputName"
              v-model="user.userName"
              name="name"
              aria-describedby="NameHelp"
              info="이름"
            />
            <div id="NameHelp" class="form-text helper">&nbsp;</div>
          </div>

          <div class="mb-3">
            <label for="InputNumber" class="form-label">전화번호</label>
            <input
              type="text"
              class="form-control check"
              id="InputNumber"
              aria-describedby="NumberHelp"
              v-model="user.userPhone"
              name="phone"
              info="전화번호"
            />
            <div id="NumberHelp" class="form-text helper">&nbsp;</div>
          </div>

          <div class="mb-3">
            <label for="InputEmail" class="form-label">Email</label>
            <input
              type="email"
              class="form-control check"
              id="InputEmail"
              aria-describedby="EmailHelp"
              v-model="user.userEmail"
              name="email"
              info="Email주소"
            />
            <div id="EmailHelp" class="form-text helper">&nbsp;</div>
          </div>
          <div class="mb-3">
            <label for="InputLocation" class="form-label">주소</label>
            <input
              type="text"
              class="form-control check"
              id="InputLocation"
              aria-describedby="LocationHelp"
              v-model="user.userAddress"
              name="address"
              info="주소"
            />
            <div id="LocationHelp" class="form-text helper">&nbsp;</div>
          </div>
          
          <p class="mb-0"><label>주변상가 선호 카테고리</label></p>
          <p :style="{'font-size': 'xx-small'}">(최대 3개)</p>
          <div class="text-center">
            <div class="mb-2 inline" v-for="(opt, idx) in storeOptions" :key="idx">
              <input type="checkbox"  :value="opt.code" v-model.number="storeCode" :disabled="!isChecked(opt.code) && isDisabled" />
              <label for=""> {{opt.codeName}}</label>
            </div>
          </div>
          <button @click.prevent="regist" class="confirm1">회원가입</button>
          <br />
        </form>
      </div>
    </div>
</div>

</template>
<script>
import http from '@/util/http-common.js';
export default {
  name: "UserInfo",
  data() {
    return {
        user : {
            userPassword: "",
            userId: "",
            userName: "",
            userPhone: "",
            userEmail: "",
            userAddress: "",
        },

        storeOptions : [],
        storeCode : []

    };
  },
  computed : {
    isDisabled(){
      return this.storeCode.length > 2;
    },
  },
  created(){
    http.get('/codes?groupCode=3')
      .then( ({data}) => {
        this.storeOptions = data;
      })
      .catch(error => {
        console.log(error);
      })
  },
  methods : {
      regist(){
          http.post(
              '/users',
              JSON.stringify({
                user : this.user, 
                storeCodeList : this.storeCode
              })
            )
            .then( ({data}) => {
                console.log(data);
                this.$router.push("/login");
            })
            .catch( error => {
                console.log(error);
                this.$alertify.error('Opps!! 서버에 문제가 발생했습니다.');
            });
      },
      isChecked(idx){
      
      let result = this.storeCode.some( el => {
        return idx == el;
      });
      return result;
    }
  }
};
</script>
<style scoped>
.inline {
  display: inline-block;
  width : 16%;
  font-size : x-small;
  text-align:center
}
.info-page {
  width: 1000px;
  padding: 2% 0 0;
  margin: auto;
}
.info-page .form {
  position: relative;
  z-index: 1;
  background: #ffffff;
  max-width: 770px;
  margin: 0 auto;
  padding: 45px;
  text-align: left;
  box-shadow: 0 0 0px 0 rgb(0 0 0 / 0%), 0 0px 0px 0 rgb(0 0 0 / 0%);
}
.info-page .form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.info-page .form .confirm1 {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background-color: #f03c02;
  width: 100%;
  border: 0;
  border-radius : 4px;
  padding: 15px;
  color: #ffffff;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.info-page .form .delete {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background-color: #ffffff;
  background-image: linear-gradient(45deg, #ffffff, #1e1915);
  width: 100%;
  border: 0;
  padding: 15px;
  color: #ffffff;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.bg {
  background-repeat: 'no-repeat';
  /* background-position:-0px -400px; */
  background-position:-5% 78%;
  background-size: cover;
  height:300px;
}
.banner{
  display: flex;
  align-items: flex-middle;
  justify-content: center;
  height: 300px;
  text-shadow: 1px 1px 10px white;
}
h1{
  font-weight: bold;
  font-size: 50px;
}
</style>
