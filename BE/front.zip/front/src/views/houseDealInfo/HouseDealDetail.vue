<template>
  <div id="ShowOne">
    <div style="display: table-cell; vertical-align: middle">
      <span @click="back">
        <img
          :src="require('@/assets/img/house/back.jpg')"
          style="height: 25px; width: 30px; padding-left: 10px"
        />
      </span>
      <span style="font-size: 15px; font-weight: bold; margin-left: 10px">매물번호</span>
      :
      {{ this.$store.state.dealOne.info.infoNo }}
    </div>
    <div>
      <div style="height: 300px">
        <img
          :src="require('@/assets/img/house/' + $store.state.dealOne.info.img)"
          alt="..."
          style="height: 300px; width: 100%"
        />
      </div>
      <div>
        <div style="padding: 10px; font-size: 20px; font-weight: bold">
          {{ this.$store.state.dealOne.info.AptName }}
          <span style="padding-left: 10p; font-size: 15px; font-weight: normal"
            >( {{ this.$store.state.dealOne.info.buildYear }}년 건축)</span
          >
        </div>
        <div style="padding-left: 10px">
          {{ this.$store.state.dealOne.info.address }} {{ this.$store.state.dealOne.info.AptName }}
          {{ this.$store.state.dealOne.info.jibun }}
        </div>
      </div>
      <div>
        <br />
        <div class="row" style="text-align: center" id="sel">
          <div class="col" :class="{ DrawOrange: isHS }" id="hs" @click="clickHs">거래내역</div>
          <div class="col" :class="{ DrawOrange: isCV }" id="cv" @click="clickConv">편의시설</div>
        </div>
        <br />
        <subcomponent v-bind:is="this.selectedComp"></subcomponent>
      </div>
    </div>
  </div>
</template>

<script>
import conv from "@/views/houseDealInfo/sub/SubCoveniences.vue";
import history from "@/views/houseDealInfo/sub/SubDealHistory.vue";
export default {
  name: "HouseDeal",
  methods: {
    back: function () {
      if (this.$store.state.selectedMarker != null) this.$store.state.selectedMarker.setMap(null);

      for (let i = 0; i < this.$store.state.store.storeList.length; i++) {
        for (let j = 0; j < this.$store.state.store.markers[i].length; j++)
          if (this.$store.state.store.markers[i] != "") {
            this.$store.state.store.markers[i][j].setMap(null);
          }
        this.$store.state.store.markers[i].splice(0, this.$store.state.store.markers[i].length);
      }
      this.$store.state.selectedComponent = "list";
    },
    clickConv: function () {
      this.selectedComp = "conv";
      this.isHS = false;
      this.isCV = true;
      this.$store.dispatch("getConvInfo", this.$store.state.dealOne.info.infoNo);
    },
    clickHs: function () {
      this.selectedComp = "history";
      this.isHS = true;
      this.isCV = false;
    },
  },
  components: {
    history,
    conv,
  },
  data: function () {
    return {
      selectedComp: "history",
      isHS: true,
      isCV: false,
    };
  },
};
</script>

<style>
#ShowOne {
  font-size: 15px;
  overflow: scroll;
  height: 1000px;
  overflow-x: hidden;
}

#sel {
  border: 1px solid #fd5c28;
}
#sel:hover {
  cursor: pointer;
  border: ;
}
.DrawOrange {
  padding: 10px;
  height: 40px;
  background-color: #fd5c28;
  color: white;
}
#hs {
  padding: 10px;
  height: 40px;
}
#cv {
  padding: 10px;
  height: 40px;
}
</style>
