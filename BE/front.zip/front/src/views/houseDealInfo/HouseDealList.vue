<template>
  <div>
    <!--
    '아파트' 라는 글자 이건 하드코딩하고
  아파트 이름 e편한 세상
  거래가 최소 ~ 최대
   주소
  -->
    <h4 class="p-3">등록된 매물 : {{ this.$store.state.deal.totalListItemCount }} 건</h4>

    <div
      v-for="(detail, index) in this.$store.state.dealList"
      v-bind:key="index"
      class="shadow row"
      v-on:click="sendIdx(detail.infoNo, index)"
      style="width: 100%; margin: 10px auto; padding: 10px"
      @mouseover="hover(index)"
      @mouseout="hout(index)"
    >
      <div class="col-5" style="height: 100%;d">
        <img
          :src="require('@/assets/img/house/' + $store.state.dealList[index].img)"
          alt="..."
          style="height: 150px; width: 100%"
        />
      </div>
      <div class="col-7">
        <span style="font-size: 15px"> 아파트</span><br />
        <span style="font-size: 22px; font-weight: bold">{{ detail.AptName }}</span
        ><br />
        <span style="font-size: 18px">최저가{{ detail.minAmount }}</span
        ><br />
        <span style="font-size: 18px">최고가{{ detail.maxAmount }}</span
        ><br />
        <span style="font-size: 18px">{{ detail.address }}</span>
      </div>
    </div>
    <pagenation v-on:call-parent="movePage"></pagenation>
  </div>
</template>

<script>
import Pagenation from "@/components/Pagenation.vue";
export default {
  methods: {
    hover: function (index) {
      this.$emit("hover", index);
    },
    hout: function () {
      this.$emit("hout");
    },
    sendIdx: function (dno, index) {
      this.$store.dispatch("getDealInfo", dno);
      this.$store.state.dealOne.info = this.$store.state.dealList[index];
      //거래내역은 store.js에서
      this.$store.state.dealIndex = index;
      this.$store.state.selectedComponent = "one";
    },
    boardList() {
      this.$store.dispatch("boardList");
    },
    // pagination
    movePage(pageIndex) {
      console.log("BoardMainVue : movePage : pageIndex : " + pageIndex);

      // store commit 으로 변경
      // this.offset = (pageIndex - 1) * this.listRowCount;
      // this.currentPageIndex = pageIndex;
      this.$store.commit("SET_BOARD_MOVE_PAGE", pageIndex);
      this.boardList();
    },
  },
  components: {
    Pagenation,
  },
};
</script>
