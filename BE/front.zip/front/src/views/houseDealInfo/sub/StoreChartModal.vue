<template>
<div class="modal" tabindex="-1" id="storeChartModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">주변상가 비율</h5>
        <button type="button" @click="closeModal" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <store-chart v-if="loaded" :chart-data="datacollection" :options="options"></store-chart>
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>
</template>

<script>
import StoreChart from '@/views/houseDealInfo/sub/StoreChart.vue';
export default {
    name : `StoreChartModal`,
    data() {
        return {
            loaded : false,
            datacollection : {
                labels: [
                    '도서관/독서실',
                    '무도/유흥/가무',
                    '세탁소/빨래방',
                    '스포츠/운동',
                    '연극/영화/극장',
                    '유흥주점',
                    '음/식료품소매',
                    '음식점',
                    '이/미용/건강',
                    '치킨/분식/패스트푸드',
                    '카페/제과제빵',
                    'PC/오락/당구/볼링등'
                ],


                datasets: [{
                    label: '역삼동',
                    data: [6*10,12*9,22*7,1*30,1*3,51*4,15*8,201,161,94,87,9*10],
                    fill: true,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgb(255, 99, 132)',
                    pointBackgroundColor: 'rgb(255, 99, 132)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgb(255, 99, 132)'
                }, {
                    label: '서울시 평균',
                    data: [6.4353*7, 11.0500*5, 15.9009*5, 3.2265*10, 2.4639*10, 37.3532*4, 23.4000*4, 147.8906, 68.8141*2, 54.9189*2, 60.9737*2, 10.2159*6],
                    fill: true,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgb(54, 162, 235)',
                    pointBackgroundColor: 'rgb(54, 162, 235)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgb(54, 162, 235)'
                }]
            }, 
            options: {
                elements: {
                    line: {
                        borderWidth: 3
                    }
                },
                 scale: {
                    ticks: {
                    // suggestedMin: 10,
                    // suggestedMax: 200
                    // max : 160,
                    // min : 10,
                    // stepSize : 40,
                }
                 },
                legend: {
                    // display: false,
                }
            },
        }
    },
    components : { StoreChart },
    created() {
        this.loaded = true;
    },
    methods : {
        closeModal(){
          this.$emit('call-parent-update'); // no parameter
        }
    }


}
</script>