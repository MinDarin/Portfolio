<template>
  <div>
    <span style="padding-left: 10px; font-size: 15px; font-weight: bold">1km 이내 주변 상권</span>
    <hr />
    <div class="row" style="text-align: center; font-weight: bold">
      <div class="col">색상</div>
      <div class="col">분류</div>
      <div class="col">요소 값</div>
      <div class="col">지도에 표시</div>
    </div>
    <hr />
    <div v-for="(detail, index) in this.$store.state.store.storeList" v-bind:key="index">
      <div class="row" style="text-align: center">
        <div class="col"><img :src="imgSrc[index]" width="15px" height="15px" /></div>
        <div class="col">{{ detail[0].codeName }}</div>
        <div class="col">{{ detail.length }}</div>
        <div class="col">
          <input
            type="checkbox"
            :name="index"
            :value="index"
            v-model="$store.state.store.checked"
          />
        </div>
      </div>
      <hr />
    </div>
    <button class="btn btn-primary" @click="openModal" >차트</button>
    <store-chart-modal v-on:call-parent-update="closeModal"></store-chart-modal>
  </div>
</template>

<script>
import StoreChartModal from '@/views/houseDealInfo/sub/StoreChartModal.vue';
import { Modal } from 'bootstrap';
export default {
  name: "conv",
  components : {StoreChartModal},
  data() {
    return {
      imgSrc: [
        require("@/assets/img/markers/marker1.png"),
        require("@/assets/img/markers/marker2.png"),
        require("@/assets/img/markers/marker3.png"),
      ],
      chartModal : null,
    };
  },
  methods : {
    openModal(){
      this.chartModal.show();
    },
    closeModal(){
      this.chartModal.hide();
    },
  },
  mounted() {
    this.chartModal = new Modal(document.getElementById('storeChartModal'));
  }
};
</script>
