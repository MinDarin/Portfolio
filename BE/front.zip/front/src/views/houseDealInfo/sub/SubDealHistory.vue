<template>
  <div>
    <span style="padding-left: 10px; font-size: 15px; font-weight: bold">거래내역</span
    ><span> {{ this.$store.state.dealOne.dealHistory.length }}건</span>
    <hr />
    <div class="row" style="text-align: center; font-weight: bold">
      <div class="col-4">거래날짜</div>
      <div class="col-3">가격</div>
      <div class="col-3">면적</div>
      <div class="col-2">층</div>
    </div>
    <hr />
    <div
      class="row"
      style="text-align: center"
      v-for="(detail, index) in this.$store.state.dealOne.dealHistory"
      v-bind:key="index"
    >
      <div class="col-4">{{ detail.dealYear }}-{{ detail.dealMonth }}-{{ detail.dealDay }}</div>
      <div class="col-3">
        {{ detail.dealAmount }}
      </div>
      <div class="col-3">
        {{ detail.area }}
      </div>
      <div class="col-2">
        {{ detail.floor }}
      </div>
    </div>
    <hr />
  </div>
</template>

<script>
export default {
  name: "history",
};
</script>
