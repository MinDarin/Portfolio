<template>
    <div>
        <div class="bg" :style="{'backgroundImage': 'url(' + require('@/assets/img/slide/slide-4.jpg') + ')'}">
      <div class="banner align-items-center text-dark text-center">
        <h1 class="">공지사항</h1>
      </div>
    </div>
      <div class="container">
        <div class="modal-body">
        <table class="table table-hover">
          <tbody>
            <tr><td>글번호</td><td>{{ $store.state.notice.noticeNo }}</td></tr>
            <tr><td>제목</td><td>{{ $store.state.notice.title }}</td></tr>
            <tr><td>내용</td><td v-html="$store.state.notice.content"></td></tr>
            <tr><td>작성자</td><td>{{ $store.state.notice.userName }}</td></tr>
            <!-- 아래 코드는 오류 발생 초기 생성 시점에 regDt = {} -->
            <!-- <tr><td>작성일시</td><td>{{ makeDateStr(regDt.date.year, regDt.date.month, regDt.date.day, '.') }}</td></tr> -->
            <tr><td>작성일시</td><td>{{ $store.state.notice.regDt }}</td></tr>
            <tr><td>조회수</td><td>{{ $store.state.notice.readCount }}</td></tr>
            <!-- New for FileUpload -->
            <tr><td colspan="2">첨부파일</td></tr>
            <tr>
              <td colspan="2">
                <div v-for="(file, index) in $store.state.notice.fileList" :key="index">
                  <span class="fileName">{{ file.fileName }}</span>
                  &nbsp;&nbsp;
                  <a type="button" class="btn btn-outline btn-default btn-xs" v-bind:href="file.fileUrl" download>내려받기</a>
                </div>
              </td>
            </tr>
            <!-- / New for FileUpload -->
          </tbody>
        </table>
      </div>
      <button v-if="$store.state.login.userRole == 1" @click="changeToUpdate" class="btn btn-sm btn-primary btn-outline" type="button">글 수정하기</button>
        <button v-if="$store.state.login.userRole == 1" @click="changeToDelete" class="btn btn-sm btn-warning btn-outline" type="button">글 삭제하기</button>
    </div>
    </div>
    
</template>

<script>
import http from '@/util/http-common.js';
export default {
    name : "NoticeDetail",
    methods : {
        changeToUpdate(){
            this.$router.push("/notice-update");
        },
        changeToDelete() {
            http.delete('/notices/' + this.$store.state.notice.noticeNo)
                .then( () =>{
                  this.$router.push("/notice");
                })
                .catch( error => {
                    console.error(error);
                })
        }
    }
}
</script>

<style scoped>
.bg {
  background-repeat: 'no-repeat';
  /* background-position:-0px -400px; */
  background-position:-5% 78%;
  background-size: cover;
  height:300px;
}
.banner{
  display: flex;
  align-items: flex-middle;
  justify-content: center;
  height: 300px;
  text-shadow: 1px 1px 10px white;
}
h1{
  font-weight: bold;
  font-size: 50px;
}
</style>