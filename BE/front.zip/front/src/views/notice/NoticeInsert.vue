<template>
    <div class="container">
        <h5 class="modal-title">공지사항 등록</h5>
        <div class="modal-body">

        <div class="mb-3">
          <input v-model="title" type="text" class="form-control" placeholder="제목">
        </div>
        <div class="mb-3">
          <div id=divEditorInsert></div>
        </div>
        <div class="form-check mb-3">
          <input v-model="attachFile" class="form-check-input" type="checkbox" value="" id="chkFileUploadInsert">
          <label class="form-check-label" for="chkFileUploadInsert">파일 추가</label>
        </div>
        <div class="mb-3" v-show="attachFile" id="imgFileUploadInsertWrapper">
          <input @change="changeFile" type="file" id="inputFileUploadInsert" multiple>
          <div id="imgFileUploadInsertThumbnail" class="thumbnail-wrapper">
            <!-- vue way img 를 만들어서 append 하지 않고, v-for 로 처리 -->
            <img v-for="(file, index) in fileList" v-bind:src="file" v-bind:key="index">
          </div>
        </div>
      </div>
      <button @click="noticeInsert" class="btn btn-sm btn-primary btn-outline" data-dismiss="modal" type="button">등록</button>
    </div>
</template>

<script>
import Vue from 'vue';
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

Vue.use(CKEditor);

import http from "@/util/http-common.js";

export default {
    name: 'NoticeInsert',
    data() {
        return {
            title: '',
            CKEditor: '',
            attachFile: false,
            fileList: []
        }
    },
    methods: {
        initUI(){
            this.title = '';
            this.CKEditor.setData('');
            this.attachFile = false;
            this.fileList = [];
            document.querySelector("#inputFileUploadInsert").value = '';
        },
        changeFile(fileEvent) {
            if( fileEvent.target.files && fileEvent.target.files.length > 0 ){

            for( var i=0; i<fileEvent.target.files.length; i++ ){
                const file = fileEvent.target.files[i];
                this.fileList.push(URL.createObjectURL(file));
            }
            }
        },
        noticeInsert(){
            var formData = new FormData();
            formData.append("title", this.title);
            formData.append("content", this.CKEditor.getData());

            // file upload
            var attachFiles = document.querySelector("#inputFileUploadInsert");

            var cnt = attachFiles.files.length;
            for(var i=0; i<cnt; i++){
                formData.append("file", attachFiles.files[i]);
            }

            http.post( '/notices', formData)
                .then( () => {
                    this.$router.push("/notice");
                })
                .catch( (error) => {
                    console.error(error.stack);
                });
        }
    },
    mounted() {
        ClassicEditor
        .create(document.querySelector('#divEditorInsert'))
        .then(editor => {
            this.CKEditor = editor;
            this.initUI();
        })
        .catch(error => {
            console.error(error.stack);
        });
    }   
}
</script>

<style>
/* CKEditor 는 vue 와 별개로 rendering 되어서 scope 를 넣으면 반영되지 않는다. */
.ck-editor__editable {
    min-height: 300px !important;
}

.thumbnail-wrapper{
	margin-top: 5px;
}

.thumbnail-wrapper img {
	width: 100px !important;
	margin-right: 5px;
	max-width: 100%;
}
</style>