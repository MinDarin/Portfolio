<template>
  <div class="mainSection">
    <div class="bg" :style="{'backgroundImage': 'url(' + require('@/assets/img/slide/slide-4.jpg') + ')'}">
      <div class="banner align-items-center text-dark text-center">
        <h1 class="">공지사항</h1>
      </div>
    </div>
    <!-- <img :src="require('@/assets/img/slide/slide-4.jpg')" class="d-block big" alt="..."> -->
    <div class="container">
      <div class="input-group mt-5 mb-3">
        <p class="me-5">총 {{$store.state.notice.totalListItemCount}} 건</p>
        <input v-model="$store.state.notice.searchWord" type="text" class="form-control ms-5" :style="{'width': '300px'}">
        <button @click="getList" class="btn btn-success" type="button" >Search</button>
      </div>
    <div>
      <table class="table table-hover">
        <thead>
          <tr>
            <th>#</th>
            <th>제목</th>
            <th>작성자</th>
            <th>작성일시</th>
            <th>조회수</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(notice, idx) in noticeList" @click="noticeDetail(notice.noticeNo)" :key="idx">
            <td>{{notice.noticeNo}}</td>
            <td>{{notice.title}}</td>
            <td>{{notice.userName}}</td>
            <td>{{notice.regDt}}</td>
            <td>{{notice.readCount}}</td>
          </tr>
        </tbody>
      </table>
        
    <notice-pagenation v-on:call-parent="movePage"></notice-pagenation>
    
    <button v-if="$store.state.login.userRole == 1" @click="mvInsert" class="btn btn-sm btn-primary" >글쓰기</button>
    
    </div>
    </div>
    
  </div>
</template>

<script>
import http from '@/util/http-common.js';
import NoticePagenation from '@/components/NoticePagenation.vue';

export default {
  name : 'Notice',
  data() {
    return {
      noticeList : [],
    }
  },
  components : {NoticePagenation},
  created () {
    this.getList();
  },
  methods : {
    getList(){
      http.get(
        '/notices',
        {
          params: {
            limit: this.$store.state.notice.limit,
            offset: this.$store.state.notice.offset,
            searchWord : this.$store.state.notice.searchWord
          }
        })
        .then( ({data}) =>{
          // console.log(data.list);
          this.noticeList = data.list;
          console.log(data.count);
          this.$store.commit('SET_NOTICE_TOTAL_LIST_ITEM_COUNT', data.count);
        })
        .catch( error => {
            console.error(error);
        })
    },
    noticeDetail(noticeNo){
      http.get(
        '/notices/' + noticeNo
        )
        .then( ({data}) =>{
          console.log(data);
          this.$store.commit('SET_NOTICE_DETAIL', data);
          this.$router.push('/notice/' + noticeNo);
        })
        .catch( error => {
            console.error(error);
        })
    },
    mvInsert(){
      this.$router.push("/notice-insert");
    },
    // pagination
    movePage(pageIndex) {
      
      this.$store.commit("SET_NOTICE_MOVE_PAGE", pageIndex);
      this.getList();
    },
  },
  

  
}
</script>

<style scoped>
img {
  /* 1920×1281 */
  position: fixed;
  clip: rect( 600px, 1281px, 1920px, 0px );
}
.bg {
  background-repeat: 'no-repeat';
  /* background-position:-0px -400px; */
  background-position:-5% 78%;
  background-size: cover;
  height:300px;
}
.banner{
  display: flex;
  align-items: flex-middle;
  justify-content: center;
  height: 300px;
  text-shadow: 1px 1px 10px white;
}
h1{
  font-weight: bold;
  font-size: 50px;
}
</style>