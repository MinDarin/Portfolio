<template>
    <div class="container">
        <h5 class="title">공지사항 수정</h5>

        <div class="">
            <div class="mb-3">
                <input v-model="$store.state.notice.title" type="text" class="form-control" placeholder="제목">
                </div>
                <div class="mb-3">
                <div id=divEditorUpdate></div>
                </div>
                <!-- 기존 파일 내용 보여줌  -->
                <!-- 새로운 첨부파일은 data-fileList 로 -->
                <div v-if="$store.state.notice.fileList.length > 0" class="mb-3">
                첨부파일 : <span><div v-for="(file, index) in $store.state.notice.fileList" class="fileName" :key="index">{{file.fileName}}</div></span>
                </div>
                <div class="form-check mb-3">
                <input v-model="attachFile" class="form-check-input" type="checkbox" value="" id="chkFileUploadUpdate">
                <label class="form-check-label" for="chkFileUploadUpdate">파일 추가</label>
                </div>
                <div class="mb-3" v-show="attachFile" id="imgFileUploadUpdateWrapper">
                <input @change="changeFile" type="file" id="inputFileUploadUpdate" multiple>
                <div id="imgFileUploadUpdateThumbnail" class="thumbnail-wrapper">
                    <!-- vue way img 를 만들어서 append 하지 않고, v-for 로 처리 -->
                    <img v-for="(file, index) in fileList" v-bind:src="file" v-bind:key="index">
                </div>
            </div>
      </div>
      <button @click="noticeUpdate" class="btn btn-sm btn-primary btn-outline" data-dismiss="modal" type="button">수정</button>
    </div>
</template>

<script>
import http from '@/util/http-common.js';
import Vue from 'vue';
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
Vue.use(CKEditor);

export default {
    name:'NoticeUpdate',
    data() {
        return {
            CKEditor : '',
            attachFile : false,
            fileList: this.$store.state.notice.fileList,
        }
    },
    methods: {
        changeFile(fileEvent) {
          if( fileEvent.target.files && fileEvent.target.files.length > 0 ){

            for( var i=0; i<fileEvent.target.files.length; i++ ){
              const file = fileEvent.target.files[i];
              this.fileList.push(URL.createObjectURL(file));
            }
          }
        },
        noticeUpdate(){
          // post form data
          var formData = new FormData();
          formData.append("noticeNo", this.$store.state.notice.noticeNo); // update 에 추가
          formData.append("title", this.$store.state.notice.title);
          formData.append("content", this.CKEditor.getData()); // store X !!!!

          // file upload
          var attachFiles = document.querySelector("#inputFileUploadUpdate");
          console.log("UpdateModalVue: data 1 : ");
          console.log(attachFiles);

          var cnt = attachFiles.files.length;
          for (var i = 0; i < cnt; i++) {
            formData.append("file", attachFiles.files[i]);
          }
          // not put, REST but FileUpload
          http.post(
            '/notices/' + this.$store.state.notice.noticeNo, // store boardId 
            formData,
            { headers: { 'Content-Type': 'multipart/form-data' } })
            .then(({ data }) => {
              console.log("UpdateModalVue: data : ");
              console.log(data);
              if( data.result == 'login' ){
                this.$router.push("/login")
              }else{
                console.log("글이 수정되었습니다.");
                this.$router.push("/notice");
              }
            })
            .catch((error) => {
              console.log("UpdateModalVue: error ");
              console.log(error);
            });
        }, 
    },
    mounted() {
        console.log(this.fileList);
        ClassicEditor
        .create(document.querySelector('#divEditorUpdate'))
        .then(editor => {
            this.CKEditor = editor;
            
            this.CKEditor.setData( this.$store.state.notice.content);
        })
        .catch(error => {
            console.error(error.stack);
        });
    }
}
</script>

<style>
/* CKEditor 는 vue 와 별개로 rendering 되어서 scope 를 넣으면 반영되지 않는다. */
.ck-editor__editable {
    min-height: 300px !important;
}

.thumbnail-wrapper{
	margin-top: 5px;
}

.thumbnail-wrapper img {
	width: 100px !important;
	margin-right: 5px;
	max-width: 100%;
}
</style>