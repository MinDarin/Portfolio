module.exports = {
    outputDir : '../HappyHouseServer/src/main/resources/static',
};